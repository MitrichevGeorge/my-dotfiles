#!/bin/bash

if eww windows | grep '*quicksettings'; then
  eww close quicksettings
else
  eww open quicksettings
fi
