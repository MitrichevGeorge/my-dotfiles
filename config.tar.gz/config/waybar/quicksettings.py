#!/usr/bin/env python3
import gi
import subprocess

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gtk, Gdk


class QuickSettings(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self, title="Quick Settings")
        self.set_decorated(False)
        self.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self.set_keep_above(True)
        self.set_default_size(280, 220)

        # позиция справа сверху
        screen = Gdk.Screen.get_default()
        monitor = screen.get_monitor_geometry(0)
        x = monitor.x + monitor.width - 300   # 300px от правого края
        y = monitor.y + 40                    # 40px от верхнего края
        self.move(x, y)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin=15)
        self.add(vbox)

        # WiFi toggle
        wifi_btn = Gtk.Button(label="Wi-Fi")
        wifi_btn.connect("clicked", self.toggle_wifi)
        vbox.pack_start(wifi_btn, False, False, 0)

        # Bluetooth toggle
        bt_btn = Gtk.Button(label="Bluetooth")
        bt_btn.connect("clicked", self.toggle_bluetooth)
        vbox.pack_start(bt_btn, False, False, 0)

        # Volume slider
        vol = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 1)
        vol.set_value(self.get_volume())
        vol.connect("value-changed", self.set_volume)
        vbox.pack_start(vol, False, False, 0)

        # Brightness slider
        bright = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 1, 100, 1)
        bright.set_value(self.get_brightness())
        bright.connect("value-changed", self.set_brightness)
        vbox.pack_start(bright, False, False, 0)

    # === WiFi ===
    def toggle_wifi(self, _):
        state = subprocess.check_output(["nmcli", "radio", "wifi"]).decode().strip()
        new_state = "off" if state == "enabled" else "on"
        subprocess.run(["nmcli", "radio", "wifi", new_state])

    # === Bluetooth ===
    def toggle_bluetooth(self, _):
        try:
            out = subprocess.check_output(["bluetoothctl", "show"]).decode()
            if "Powered: yes" in out:
                subprocess.run(["bluetoothctl", "power", "off"])
            else:
                subprocess.run(["bluetoothctl", "power", "on"])
        except subprocess.CalledProcessError:
            pass

    # === Volume ===
    def get_volume(self):
        out = subprocess.check_output(["pamixer", "--get-volume"]).decode().strip()
        return int(out)

    def set_volume(self, slider):
        subprocess.run(["pamixer", "--set-volume", str(int(slider.get_value()))])

    # === Brightness ===
    def get_brightness(self):
        out = subprocess.check_output(["brightnessctl", "g"]).decode().strip()
        maxv = subprocess.check_output(["brightnessctl", "m"]).decode().strip()
        return int(int(out) / int(maxv) * 100)

    def set_brightness(self, slider):
        subprocess.run(["brightnessctl", "s", f"{int(slider.get_value())}%"])


if __name__ == "__main__":
    win = QuickSettings()
    win.show_all()
    Gtk.main()

