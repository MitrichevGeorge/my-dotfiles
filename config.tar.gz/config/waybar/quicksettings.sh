#!/bin/bash
pgrep -f quicksettings.py >/dev/null && pkill -f quicksettings.py || python ~/.config/waybar/quicksettings.py &

