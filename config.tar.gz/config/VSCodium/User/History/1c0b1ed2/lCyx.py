# tg_via_proxy.py
import asyncio
import socks
from telethon import TelegramClient, errors
from pars import getproxy

pr = getproxy()

async def main():
    print("Заполните данные (ввод в консоли):")
    api_id = int(input("api_id: ").strip())
    api_hash = input("api_hash: ").strip()

    proxy_ip = pr[0]["ip"]
    proxy_port = int(pr[0]["port"])

    phone = input("номер телефона в формате +71234567890: ").strip()

    # формируем proxy tuple для Telethon (PySocks-совместимый формат)
    proxy = (socks.SOCKS5, proxy_ip, proxy_port)

    client = TelegramClient('session_proxy', api_id, api_hash, proxy=proxy)

    await client.connect()
    try:
        if not await client.is_user_authorized():
            # отправляем код
            try:
                sent = await client.send_code_request(phone)
            except Exception as e:
                print("Ошибка при отправке кода (возможно проблема с прокси/соединением):", e)
                await client.disconnect()
                return

            code = input("Код из SMS/входящего (или из Telegram в другом устройстве): ").strip()

            try:
                await client.sign_in(phone=phone, code=code)
            except errors.SessionPasswordNeededError:
                # требуется 2FA пароль
                pwd = input("Требуется 2FA пароль (введите): ").strip()
                try:
                    await client.sign_in(password=pwd)
                except Exception as e:
                    print("Не удалось войти с 2FA паролем:", e)
                    await client.disconnect()
                    return
            except Exception as e:
                print("Ошибка при sign_in:", e)
                await client.disconnect()
                return

        # авторизован — отправляем "привет" в Saved Messages (в избранное)
        try:
            await client.send_message('me', 'привет')
            print("Сообщение отправлено в Избранное (Saved Messages).")
        except Exception as e:
            print("Ошибка при отправке сообщения:", e)

    finally:
        await client.disconnect()


if __name__ == '__main__':
    asyncio.run(main())
