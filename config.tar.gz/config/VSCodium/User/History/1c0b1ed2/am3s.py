# tg_via_proxy.py
import asyncio
import socks
from telethon import TelegramClient, errors
from pars2 import getproxy_cached

pr = getproxy_cached()

async def main():
    print("Заполните данные (ввод в консоли):")
    api_id = 24562157
    api_hash = "6ec6241e31f57d6cbe7e82e6258b2668"

    proxy_ip = pr[0]["ip"]
    proxy_port = int(pr[0]["port"])

    phone = input("номер телефона в формате +71234567890: ").strip()

    proxy = (socks.SOCKS5, proxy_ip, proxy_port)

    client = TelegramClient('session_proxy', api_id, api_hash, proxy=proxy)

    await client.connect()
    try:
        try:
            sent = await client.send_code_request(phone)
        except Exception as e:
            print("Ошибка при отправке кода (возможно проблема с прокси/соединением):", e)
            await client.disconnect()
            return



if __name__ == '__main__':
    asyncio.run(main())
