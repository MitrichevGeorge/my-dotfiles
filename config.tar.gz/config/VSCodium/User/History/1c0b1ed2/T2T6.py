
import asyncio
import socks
from telethon import TelegramClient, errors
from pars2 import getproxy_cached
from random import randint

pr = getproxy_cached()

async def main():
    api_id = 24562157
    api_hash = "6ec6241e31f57d6cbe7e82e6258b2668"

    if not pr:
        print("Нет прокси")
        return

    
    phone = input("номер: ").strip()

    for q in pr:
        proxy_ip = q.get("ip")
        proxy_port_str = q.get("port") or ""
        try:
            proxy_port = int(proxy_port_str)
        except ValueError:
            print("Непр порт:", proxy_port_str)
            return


        proxy = (socks.SOCKS5, proxy_ip, proxy_port)

        client = None
        z = randinr(1,3)
        if z == 1:
            client = TelegramClient(
                'session_proxy',
                api_id,
                api_hash,
                proxy=proxy,
                device_model="Pixel 7",
                system_version="Android 14",
                app_version="9.0.0",
                lang_code="ru",
                system_lang_code="ru-RU"
            )
        elif z == 2:
            client = TelegramClient(
                'session_proxy',
                api_id,
                api_hash,
                proxy=proxy,
                device_model="HP Pavilion P9",
                system_version="Windows 11",
                app_version="3.2.0",
                lang_code="ru",
                system_lang_code="ru-RU"
            )
        elif z == 3:
            client = TelegramClient(
                'session_proxy',
                api_id,
                api_hash,
                proxy=proxy,
                device_model="Ipad Air 12",
                system_version="IOS 13",
                app_version="9.12.3",
                lang_code="ru",
                system_lang_code="ru-RU"
            )

        await client.connect()
        try:
            try:
                sent = await client.send_code_request(phone)
                print("Код запрошен")
            except Exception as e:
                print(e)
                await client.disconnect()
                return
        except Exception as e:
            print(e)
        finally:
            await client.disconnect()


if __name__ == '__main__':
    asyncio.run(main())
