
import asyncio
import socks
from telethon import TelegramClient, errors
from pars2 import getproxy_cached
from random import randint

pr = getproxy_cached()

async def main():
    print("Заполните данные (ввод в консоли):")
    api_id = 24562157
    api_hash = "6ec6241e31f57d6cbe7e82e6258b2668"

    if not pr:
        print("Нет прокси в кеше. Проверь getproxy_cached()")
        return

    # 안전но получить ip/port
    proxy_ip = pr[0].get("ip")
    proxy_port_str = pr[0].get("port") or ""
    try:
        proxy_port = int(proxy_port_str)
    except ValueError:
        print("Неправильный порт у прокси:", proxy_port_str)
        return

    phone = input("номер телефона в формате +71234567890: ").strip()

    proxy = (socks.SOCKS5, proxy_ip, proxy_port)


    client = TelegramClient(
        'session_proxy',
        api_id,
        api_hash,
        proxy=proxy,
        device_model="Pixel 7",
        system_version="Android 14",
        app_version="9.0.0",
        lang_code="ru",
        system_lang_code="ru-RU"
    )

    await client.connect()
    try:
        try:
            sent = await client.send_code_request(phone)
            print("Код успешно запрошен (код придёт на телефон).")
        except Exception as e:
            print("Ошибка при отправке кода (возможно проблема с прокси/соединением):", e)
            await client.disconnect()
            return

    finally:
        await client.disconnect()


if __name__ == '__main__':
    asyncio.run(main())
