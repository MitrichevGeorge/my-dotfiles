TOKEN = '7386029566:AAG-JedZjP0e08ApeanIfhUs3gjvjQCo9Rg'

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, Bot, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from telegram.ext import Application, ChatJoinRequestHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes


async def chat_join_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    join_request = update.chat_join_request
    user_id = join_request.from_user.id
    chat_id = join_request.chat.id
    user_chat_id = join_request.user_chat_id

    context.user_data[user_id] = {
        'chat_id': chat_id,
        'user_chat_id': user_chat_id,
        'started': True
    }
    

    button1 = KeyboardButton("✅ Вступить в канал")
    keyboard = [[button1]]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

    try:
        await context.bot.send_message(
            chat_id=user_chat_id,
            text="Нажми кнопку ниже чтоб вступить в канал",
            reply_markup=reply_markup
        )
    except Exception as e:
        print(f"Ошибка при отправке сообщения: {e}")

async def handle_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not context.user_data[user_id].get('started', False):
        return
    user_text = update.message.text

    if user_text == "✅ Вступить в канал":
        data = context.user_data[user_id]

        await context.bot.approve_chat_join_request(
            chat_id=data['chat_id'],
            user_id=user_id
        )
        data['started'] = False
        await update.message.reply_text(f"Заявка принята. Добро пожаловать в ShadowTech! 🎉", reply_markup=ReplyKeyboardRemove())


def main():
    app = Application.builder().token(TOKEN).build()

    app.add_handler(ChatJoinRequestHandler(chat_join_request))

    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_button))

    print("Бот запущен...")
    app.run_polling()

if __name__ == '__main__':
    main()