# utils.py
from functools import wraps
from telegram import Update
from telegram.ext import ContextTypes
from aiolimiter import AsyncLimiter
import asyncio

GLOBAL_LIMITER = AsyncLimiter(50, 1)
USER_LIMITER = AsyncLimiter(5, 1)
COMMAND_LIMITER = AsyncLimiter(1, 300)

_pending_warnings = {}

def rate_limit(limiter_type: str = "user", silent_after_first: bool = True):
    def decorator(func):
        @wraps(func)
        async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
            user_id = update.effective_user.id
            message = update.message

            if not await GLOBAL_LIMITER.acquire():
                return

            limiter = {"user": USER_LIMITER, "command": COMMAND_LIMITER}.get(limiter_type)
            if not limiter:
                return await func(update, context)

            key = f"{limiter_type}:{user_id}"

            if await limiter.acquire():
                return await func(update, context)

            if not silent_after_first:
                await message.reply_text("Слишком быстро! Подожди.")
                return

            warning_key = f"warn:{key}"
            if warning_key in _pending_warnings:
                return

            warning_msg = await message.reply_text("Слишком быстро! Подожди немного.")

            async def cleanup():
                await asyncio.sleep(5)
                try:
                    await warning_msg.delete()
                except:
                    pass
                _pending_warnings.pop(warning_key, None)

            _pending_warnings[warning_key] = asyncio.create_task(cleanup())
            return

        return wrapper
    return decorator