from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, ContextTypes

# Замени на свой токен
TOKEN = 'YOUR_BOT_TOKEN_HERE'

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Получаем параметр после /start
    args = context.args
    if args and args[0] == "8284":
        await update.message.reply_text("Код 8284 принят! Добро пожаловать! 🎉")
        return

    # Получаем username бота
    bot = context.bot
    bot_username = (await bot.get_me()).username

    # Создаём кнопку с ссылкой t.me/bot?start=8284
    url = f"https://t.me/{bot_username}?start=8284"
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("Нажми меня!", url=url)]
    ])

    await update.message.reply_text(
        "Привет! Нажми кнопку ниже:",
        reply_markup=keyboard
    )

def main():
    # Создаём Application
    app = Application.builder().token(TOKEN).build()

    # Регистрируем команду /start
    app.add_handler(CommandHandler("start", start))

    # Запускаем бота
    print("Бот запущен...")
    app.run_polling()

if __name__ == '__main__':
    main()