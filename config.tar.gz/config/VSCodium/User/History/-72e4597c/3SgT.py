from aiogram import Bot, Dispatcher, types, executor
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

API_TOKEN = 'YOUR_BOT_TOKEN_HERE'

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    # Получаем параметр из /start
    param = message.get_args()

    if param == "8284":
        await message.answer("Код 8284 принят! Добро пожаловать! 🎉")
        return

    # Создаём кнопку с ссылкой
    keyboard = InlineKeyboardMarkup()
    # Ссылка: t.me/YourBotUsername?start=8284
    url = f"https://t.me/{(await bot.get_me()).username}?start=8284"
    button = InlineKeyboardButton(text="Нажми меня!", url=url)
    keyboard.add(button)

    await message.answer("Привет! Нажми кнопку, чтобы активировать:", reply_markup=keyboard)

if __name__ == '__main__':
    print("Бот запущен...")
    executor.start_polling(dp, skip_updates=True)