import uuid
import asyncio
import aiosqlite
import os
import time
import logging
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import Application, ChatJoinRequestHandler, CommandHandler, ContextTypes
from dotenv import load_dotenv
import secrets

load_dotenv()

TOKEN = os.getenv("BOT_TOKEN")
ALLOWED_CHAT_ID = int(os.getenv("CHANNEL_ID"))

if not TOKEN or not ALLOWED_CHAT_ID:
    raise ValueError("BOT_TOKEN или CHANNEL_ID не заданы в .env")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DB_PATH = "requests.db"
ANT2FLOOD_DELAY = 1.0
LAST_MSG = {}


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS pending (
                token TEXT PRIMARY KEY,
                user_id INTEGER,
                user_chat_id INTEGER,
                chat_id INTEGER,
                timestamp REAL
            )
        """)
        await db.commit()


async def add_request(token: str, user_id: int, user_chat_id: int, chat_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR REPLACE INTO pending VALUES (?, ?, ?, ?, ?)",
            (token, user_id, user_chat_id, chat_id, time.time())
        )
        await db.commit()


async def get_request_by_token(token: str):
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT * FROM pending WHERE token = ?", (token,)) as cur:
            row = await cur.fetchone()
            if row:
                return dict(zip(["token", "user_id", "user_chat_id", "chat_id", "timestamp"], row))
    return None


async def delete_request(token: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM pending WHERE token = ?", (token,))
        await db.commit()


async def clean_expired():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM pending WHERE timestamp < ?", (time.time() - 3600))
        await db.commit()


async def chat_join_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    req = update.chat_join_request
    user_id = req.from_user.id
    user_chat_id = req.user_chat_id
    chat_id = req.chat.id

    if chat_id != ALLOWED_CHAT_ID:
        return

    token = secrets.token_urlsafe(16)
    await add_request(token, user_id, user_chat_id, chat_id)

    bot = context.bot
    bot_user = await bot.get_me()
    bot_username = bot_user.username

    url = f"https://t.me/{bot_username}?start={token}"
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Вступить в канал", url=url)]
    ])

    try:
        await bot.send_message(
            chat_id=user_chat_id,
            text="Нажмите кнопку ниже, чтобы вступить в канал:",
            reply_markup=keyboard
        )
    except Exception as e:
        logger.error(f"Ошибка отправки сообщения пользователю {user_id}: {e}")
        await delete_request(token)


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    message = update.effective_message

    now = time.time()
    if user_id in LAST_MSG and now - LAST_MSG[user_id] < ANT2FLOOD_DELAY:
        return
    LAST_MSG[user_id] = now

    if not context.args:
        await message.reply_text("Привет! Используйте кнопку из приглашения.")
        return

    token = context.args[0].strip()
    data = await get_request_by_token(token)

    if not data:
        await message.reply_text("❌ Заявка устарела или недействительна.")
        return

    if data["user_id"] != user_id:
        await message.reply_text("❌ Это не ваша заявка!")
        return

    if time.time() - data["timestamp"] > 3600:
        await message.reply_text("⏰ Срок действия заявки истёк.")
        await delete_request(token)
        return

    try:
        await context.bot.approve_chat_join_request(
            chat_id=data["chat_id"],
            user_id=user_id
        )
        await message.reply_text("🎉 Добро пожаловать в ShadowTech! 🎉")
    except Exception as e:
        logger.error(f"Ошибка при approve для {user_id}: {e}")
        await message.reply_text("⚠️ Произошла ошибка при вступлении.")
    finally:
        await delete_request(token)


async def cleaner_loop():
    while True:
        try:
            await clean_expired()
        except Exception as e:
            logger.error(f"Ошибка в cleaner_loop: {e}")
        await asyncio.sleep(600)


async def main():
    await init_db()

    app = Application.builder().token(TOKEN).build()

    app.add_handler(ChatJoinRequestHandler(chat_join_request))
    app.add_handler(CommandHandler("start", start_command))

    asyncio.create_task(cleaner_loop())

    logger.info("Бот запущен и готов к работе...")
    await app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    asyncio.run(main())