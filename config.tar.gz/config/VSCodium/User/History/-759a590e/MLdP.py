import re
import requests
from bs4 import BeautifulSoup

def getproxy():
    data = {
        "xx0": "cfa00012558e8cdd04d4504d75925e67", 
        "xpp": "2",
        "xf1": "0",
        "xf2": "0",
        "xf4": "0",
        "xf5": "2"
    }

    url = "https://spys.one/en/socks-proxy-list/"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
    }

    try:
        # Send POST request to mimic form submission
        res = requests.post(url, headers=headers, data=data, timeout=10)
        res.raise_for_status()  # Raise exception for bad status codes
    except requests.RequestException as e:
        print(f"Error fetching page: {e}")
        return []

    soup = BeautifulSoup(res.text, "html.parser")

    # Find all proxy rows
    rows = soup.find_all("tr", class_=re.compile(r"spy1x|spy1xx"))
    if not rows:
        print("No proxy rows found. Check website structure or request parameters.")
        return []

    # Extract JavaScript variables for port decoding
    js_vars = {}
    js_code = soup.find("script", string=re.compile(r"\w+=\d+\^\w+;"))
    if js_code:
        matches = re.findall(r"(\w+)\s*=\s*(\d+)\^(\w+);", js_code.string)
        for var, a, b in matches:
            a = int(a)
            b_val = js_vars.get(b, 0)
            js_vars[var] = a ^ b_val
    else:
        print("No JavaScript code found for port decoding.")
        return []

    proxies = []
    for row in rows:
        cols = row.find_all("td")
        if not cols or len(cols) < 2:
            continue

        # Extract IP
        ip_tag = cols[0].find("font", class_="spy14")
        if not ip_tag:
            continue
        ip = ip_tag.text.strip()

        # Extract port from JavaScript expression
        port_script = ip_tag.find_next("script")
        port = None
        if port_script:
            js_expr = port_script.string
            if js_expr:
                parts = re.findall(r"\((\w+)\^(\w+)\)", js_expr)
                port = ""
                for a, b in parts:
                    val = js_vars.get(a, 0) ^ js_vars.get(b, 0)
                    port += str(val)
                port = port.strip()

        # Extract proxy type and country
        proxy_type = cols[1].text.strip()
        country_tag = cols[3].find("font", class_="spy14")
        country = country_tag.text.strip() if country_tag else ""

        proxies.append({
            "ip": ip,
            "port": port,
            "type": proxy_type,
            "country": country
        })

    # Verify the number of proxies
    if len(proxies) < 100:
        print(f"Warning: Only {len(proxies)} proxies found, expected 100.")
    else:
        print(f"Successfully retrieved {len(proxies)} proxies.")

    return proxies[:100]  # Ensure no more than 100 proxies are returned

def main():
    proxies = getproxy()
    if not proxies:
        print("No proxies retrieved.")
        return

    for p in proxies:
        print(f"{p['ip']}:{p['port']} {p['type']} {p['country']}")

if __name__ == "__main__":
    main()