import asyncio
import websockets
from typing import Callable, List
import json

class Distributor:
    def __init__(self, dist_id: str, uri: str):
        self.dist_id = dist_id
        self.uri = f"{uri}/in/{dist_id}"
        self.handlers: List[Callable[[str], None]] = []
        self.websocket = None

    def on_message(self, func: Callable[[str], None]) -> Callable[[str], None]:
        """Декоратор для регистрации обработчиков сообщений"""
        self.handlers.append(func)
        return func

    async def send_message(self, message: str):
        """Отправка сообщения всем клиентам"""
        if self.websocket:
            await self.websocket.send_text(message)

    async def run(self):
        """Запуск дистрибьютора"""
        async with websockets.connect(self.uri) as websocket:
            self.websocket = websocket
            print(f"Distributor {self.dist_id} connected")
            try:
                while True:
                    message = await websocket.recv()
                    for handler in self.handlers:
                        await handler(message)
            except websockets.exceptions.ConnectionClosed:
                print(f"Distributor {self.dist_id} disconnected")
            finally:
                self.websocket = None

# Пример использования
dist = Distributor("dist1", "ws://77.232.128.127:8765")

@dist.on_message
async def handle_hello(message: str):
    print(f"Handler 'hello': {message}")
    if message.startswith("hello"):
        await dist.send_message(f"Received '{message}', responding with greetings!")

@dist.on_message
async def handle_time(message: str):
    print(f"Handler 'time': {message}")
    if "time" in message.lower():
        from datetime import datetime
        await dist.send_message(f"Current time: {datetime.now().strftime('%H:%M:%S')}")

if __name__ == "__main__":
    asyncio.run(dist.run())