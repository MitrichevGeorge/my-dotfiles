import asyncio
import websockets
import json

async def on_message(message):
    """Обработчик входящих сообщений от клиентов"""
    print(f"Received message: {message}")

async def distributor(dist_id: str, uri: str):
    async with websockets.connect(f"{uri}/in/{dist_id}") as websocket:
        print(f"Distributor {dist_id} connected")
        try:
            while True:
                message = await websocket.receive()
                await on_message(message)
        except websockets.exceptions.ConnectionClosed:
            print(f"Distributor {dist_id} disconnected")

if __name__ == "__main__":
    asyncio.run(distributor("dist1", "ws://77.232.128.127:8765:8000"))