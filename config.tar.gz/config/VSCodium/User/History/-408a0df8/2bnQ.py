import asyncio
import websockets
from typing import Callable, List
import json
from datetime import datetime

class Distributor:
    def __init__(self, dist_id: str, uri: str):
        self.dist_id = dist_id
        self.uri = f"{uri}/in/{dist_id}"
        self.handlers: List[tuple[str, Callable[[str], None]]] = []  # Список пар (префикс, обработчик)
        self.tasks: List[Callable[[], None]] = []  # Список внешних асинхронных задач
        self.websocket = None

    def on_message(self, prefix: str) -> Callable:
        """Декоратор для регистрации обработчиков сообщений с указанным префиксом"""
        def decorator(func: Callable[[str], None]) -> Callable[[str], None]:
            self.handlers.append((prefix, func))
            return func
        return decorator

    def register_task(self, task: Callable[[], None]) -> None:
        """Регистрация внешней асинхронной задачи"""
        self.tasks.append(task)

    async def send_message(self, message: str):
        """Отправка сообщения всем клиентам"""
        if self.websocket:
            await self.websocket.send(message)

    async def run(self):
        """Запуск дистрибьютора"""
        async with websockets.connect(self.uri) as websocket:
            self.websocket = websocket
            print(f"Distributor {self.dist_id} connected")
            # Запускаем все зарегистрированные задачи
            task_handles = [asyncio.create_task(task(self)) for task in self.tasks]
            try:
                while True:
                    message = await websocket.recv()
                    for prefix, handler in self.handlers:
                        if message.startswith(prefix):
                            await handler(message)
            except websockets.exceptions.ConnectionClosed:
                print(f"Distributor {self.dist_id} disconnected")
            finally:
                self.websocket = None
                # Отменяем все задачи при завершении
                for task in task_handles:
                    task.cancel()

# Пример асинхронной задачи вне класса
async def send_time_periodically(dist: Distributor):
    """Отправка текущего времени каждые 30 секунд"""
    while True:
        await dist.send_message(f"Current time: {datetime.now().strftime('%H:%M:%S')}")
        await asyncio.sleep(30)

# Пример другой асинхронной задачи
async def send_heartbeat(dist: Distributor):
    """Отправка heartbeat каждые 60 секунд"""
    while True:
        await dist.send_message("Heartbeat: Distributor is alive")
        await asyncio.sleep(60)

# Пример использования
dist = Distributor("dist1", "ws://77.232.128.127:8765")

# Регистрация обработчиков сообщений
@dist.on_message("hello")
async def handle_hello(message: str):
    print(f"Handler 'hello': {message}")
    await dist.send_message(f"Received '{message}', responding with greetings!")

@dist.on_message("status")
async def handle_status(message: str):
    print(f"Handler 'status': {message}")
    await dist.send_message(f"Status request received: {message}")

# Регистрация асинхронных задач
dist.register_task(send_time_periodically)
dist.register_task(send_heartbeat)

if __name__ == "__main__":
    asyncio.run(dist.run())