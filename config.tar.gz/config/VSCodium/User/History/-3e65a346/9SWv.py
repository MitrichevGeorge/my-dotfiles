# html_generator.py (ОТЛАДОЧНАЯ ВЕРСИЯ)
import aiosqlite
from jinja2 import Environment, FileSystemLoader, TemplateNotFound
import os
import asyncio

DB_NAME = "bot_chats.db"
OUTPUT_DIR = "export"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ПРОВЕРЯЕМ ПУТЬ К ШАБЛОНУ
TEMPLATE_DIR = "templates"
print(f"Ищем шаблон в: {os.path.abspath(TEMPLATE_DIR)}")
print(f"Файлы в папке: {os.listdir(TEMPLATE_DIR) if os.path.exists(TEMPLATE_DIR) else 'НЕТ ПАПКИ'}")

env = Environment(loader=FileSystemLoader(TEMPLATE_DIR))

async def generate_html():
    try:
        # 1. Проверяем, есть ли шаблон
        template = env.get_template('index.html')
        print("Шаблон index.html найден")

        async with aiosqlite.connect(DB_NAME) as db:
            # 2. Проверяем чаты
            cursor = await db.execute("SELECT COUNT(*) FROM chats")
            chat_count = (await cursor.fetchone())[0]
            print(f"Чатов в БД: {chat_count}")

            cursor = await db.execute("SELECT chat_id, title FROM chats ORDER BY title")
            raw_chats = await cursor.fetchall()
            chats = [{"id": row[0], "title": row[1] or f"Chat {row[0]}"} for row in raw_chats]
            print(f"Чаты: {chats}")

            # 3. Проверяем сообщения
            cursor = await db.execute("SELECT COUNT(*) FROM messages")
            msg_count = (await cursor.fetchone())[0]
            print(f"Сообщений в БД: {msg_count}")

            cursor = await db.execute("""
                SELECT chat_id, message_id, username, first_name, text, date, is_deleted, media_path
                FROM messages ORDER BY date
            """)
            raw_messages = await cursor.fetchall()
            messages = []
            for row in raw_messages:
                messages.append({
                    "chat_id": row[0],
                    "message_id": row[1],
                    "from": row[2] or row[3] or "Unknown",
                    "text": row[4],
                    "date": row[5][:16].replace("T", " "),
                    "deleted": bool(row[6]),
                    "media": row[7]
                })
            print(f"Первые 3 сообщения: {messages[:3]}")

        # 4. Рендерим
        html = template.render(chats=chats, messages=messages)
        output_path = os.path.join(OUTPUT_DIR, "index.html")
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)

        print(f"УСПЕХ: Экспорт сохранён → {os.path.abspath(output_path)}")

    except TemplateNotFound as e:
        print(f"ОШИБКА: Шаблон не найден: {e}")
    except Exception as e:
        print(f"ОШИБКА: {e}")
        import traceback
        traceback.print_exc()