# html_generator.py
import aiosqlite
from jinja2 import Environment, FileSystemLoader
import os
from datetime import datetime

DB_NAME = "bot_chats.db"
OUTPUT_DIR = "export"
MEDIA_DIR = "media"
os.makedirs(OUTPUT_DIR, exist_ok=True)

env = Environment(loader=FileSystemLoader('templates'))

async def generate_html():
    try:
        template = env.get_template('index.html')
        print("Шаблон index.html найден")

        async with aiosqlite.connect(DB_NAME) as db:
            # Чаты
            cursor = await db.execute("SELECT chat_id, title FROM chats ORDER BY title")
            raw_chats = await cursor.fetchall()
            chats = []
            for row in raw_chats:
                title = row[1] or f"User {row[0]}"
                if str(row[0]).startswith('-100'):
                    title = row[1] or "Group"
                chats.append({"id": row[0], "title": title})

            print(f"Чатов в БД: {len(chats)}")

            # Сообщения
            cursor = await db.execute("""
                SELECT chat_id, message_id, username, first_name, user_id, text, date, is_deleted, media_path, avatar_path
                FROM messages ORDER BY date
            """)
            raw_messages = await cursor.fetchall()
            messages = []
            for row in raw_messages:
                # Обработка даты
                raw_date = row[6]
                if isinstance(raw_date, str):
                    formatted_date = raw_date[:16].replace("T", " ")
                elif isinstance(raw_date, (int, float)):
                    formatted_date = datetime.fromtimestamp(raw_date).strftime("%Y-%m-%d %H:%M")
                else:
                    formatted_date = "Unknown"

                messages.append({
                    "chat_id": row[0],
                    "message_id": row[1],
                    "from": row[2] or row[3] or "Unknown",
                    "user_id": row[4],
                    "username": row[2],
                    "text": row[5] or "",
                    "date": formatted_date,
                    "deleted": bool(row[7]),
                    "media": row[8],
                    "avatar": row[9]
                })

            print(f"Сообщений в БД: {len(messages)}")

        # Рендер
        html = template.render(chats=chats, messages=messages)
        output_path = os.path.join(OUTPUT_DIR, "index.html")
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)

        print(f"УСПЕХ: Экспорт сохранён → {os.path.abspath(output_path)}")

    except Exception as e:
        print(f"ОШИБКА: {e}")
        import traceback
        traceback.print_exc()

# Запуск
if __name__ == "__main__":
    import asyncio
    asyncio.run(generate_html())