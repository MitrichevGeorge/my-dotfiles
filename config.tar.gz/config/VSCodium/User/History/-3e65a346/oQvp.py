# html_generator.py
import aiosqlite
from jinja2 import Environment, FileSystemLoader
import os
from datetime import datetime

DB_NAME = "bot_chats.db"
OUTPUT_DIR = "export"
MEDIA_DIR = "media"
os.makedirs(OUTPUT_DIR, exist_ok=True)

env = Environment(loader=FileSystemLoader('templates'))

async def generate_html():
    try:
        template = env.get_template('index.html')
        print("Шаблон index.html найден")

        async with aiosqlite.connect(DB_NAME) as db:
            # Чаты
            cursor = await db.execute("SELECT chat_id, title FROM chats ORDER BY title")
            raw_chats = await cursor.fetchall()
            chats = []
            for row in raw_chats:
                title = row[1] or f"User {row[0]}"
                if str(row[0]).startswith('-100'):
                    title = row[1] or "Group"
                chats.append({"id": row[0], "title": title})

            print(f"Чатов в БД: {len(chats)}")

            # Сообщения
            # html_generator.py (в generate_html, вместо старого блока chats)

            cursor = await db.execute("""
                SELECT c.chat_id, c.title, 
                    m.user_id, m.username, m.first_name
                FROM chats c
                LEFT JOIN messages m ON c.chat_id = m.chat_id AND m.user_id IS NOT NULL
                GROUP BY c.chat_id
                ORDER BY c.title
            """)
            raw_chats = await cursor.fetchall()
            chats = []

            for row in raw_chats:
                chat_id = row[0]
                default_title = row[1] or "Unknown"
                user_id = row[2]
                username = row[3]
                first_name = row[4]

                # Если это приватный чат (положительный ID) — ищем имя пользователя
                if chat_id > 0:
                    if username:
                        title = f"@{username}"
                    elif first_name:
                        title = first_name.strip()
                    else:
                        title = f"User {chat_id}"
                else:
                    # Группа или канал
                    title = default_title or "Group"

                chats.append({"id": chat_id, "title": title})

            print(f"Сообщений в БД: {len(messages)}")

        # Рендер
        html = template.render(chats=chats, messages=messages)
        output_path = os.path.join(OUTPUT_DIR, "index.html")
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)

        print(f"УСПЕХ: Экспорт сохранён → {os.path.abspath(output_path)}")

    except Exception as e:
        print(f"ОШИБКА: {e}")
        import traceback
        traceback.print_exc()

# Запуск
if __name__ == "__main__":
    import asyncio
    asyncio.run(generate_html())