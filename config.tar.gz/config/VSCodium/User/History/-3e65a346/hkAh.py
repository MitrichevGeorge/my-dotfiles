# html_generator.py
import aiosqlite
from jinja2 import Environment, FileSystemLoader
import os

DB_NAME = "bot_chats.db"
OUTPUT_DIR = "export"
os.makedirs(OUTPUT_DIR, exist_ok=True)

env = Environment(loader=FileSystemLoader('templates'))

async def generate_html():
    template = env.get_template('index.html')
    
    async with aiosqlite.connect(DB_NAME) as db:
        # Все чаты
        chats = []
        async for row in await db.execute("SELECT chat_id, title FROM chats ORDER BY title"):
            chat_id, title = row
            chats.append({"id": chat_id, "title": title or "Unknown"})

        # Все сообщения
        messages = []
        async for row in await db.execute("""
            SELECT chat_id, message_id, username, first_name, text, date, is_deleted, media_path
            FROM messages ORDER BY date
        """):
            messages.append({
                "chat_id": row[0],
                "message_id": row[1],
                "from": row[2] or row[3] or "Unknown",
                "text": row[4],
                "date": row[5],
                "deleted": row[6],
                "media": row[7]
            })

    html = template.render(chats=chats, messages=messages)
    with open(f"{OUTPUT_DIR}/index.html", "w", encoding="utf-8") as f:
        f.write(html)

    print(f"Экспорт сохранён: {OUTPUT_DIR}/index.html")