# html_generator.py
import aiosqlite
from jinja2 import Environment, FileSystemLoader
import os
from datetime import datetime

DB_NAME = "bot_chats.db"
OUTPUT_DIR = "export"
os.makedirs(OUTPUT_DIR, exist_ok=True)

env = Environment(loader=FileSystemLoader('templates'))

async def generate_html():
    try:
        template = env.get_template('index.html')
        print("Шаблон index.html найден")

        async with aiosqlite.connect(DB_NAME) as db:
            # === Чаты: определяем имя пользователя ===
            cursor = await db.execute("""
                SELECT c.chat_id, c.title, 
                       m.user_id, m.username, m.first_name
                FROM chats c
                LEFT JOIN messages m ON c.chat_id = m.chat_id AND m.user_id IS NOT NULL
                GROUP BY c.chat_id
                ORDER BY c.title
            """)
            raw_chats = await cursor.fetchall()
            chats = []
            for row in raw_chats:
                chat_id = row[0]
                default_title = row[1] or "Unknown"
                username = row[3]
                first_name = row[4]

                if chat_id > 0:  # Приватный чат
                    if username:
                        title = f"@{username}"
                    elif first_name:
                        title = first_name.strip()
                    else:
                        title = f"User {chat_id}"
                else:
                    title = default_title or "Group"
                chats.append({"id": chat_id, "title": title})

            print(f"Чатов в БД: {len(chats)}")

            # === Сообщения ===
            cursor = await db.execute("""
                SELECT chat_id, message_id, username, first_name, user_id, text, date, is_deleted, media_path, avatar_path
                FROM messages ORDER BY date
            """)
            raw_messages = await cursor.fetchall()
            messages = []
            for row in raw_messages:
                raw_date = row[6]
                if isinstance(raw_date, str):
                    formatted_date = raw_date[:16].replace("T", " ")
                elif isinstance(raw_date, (int, float)):
                    formatted_date = datetime.fromtimestamp(raw_date).strftime("%Y-%m-%d %H:%M")
                else:
                    formatted_date = "Unknown"

                messages.append({
                    "chat_id": row[0],
                    "message_id": row[1],
                    "from": row[2] or row[3] or "Unknown",
                    "user_id": row[4],
                    "username": row[2],
                    "text": row[5] or "",
                    "date": formatted_date,
                    "deleted": bool(row[7]),
                    "media": row[8],
                    "avatar": row[9]
                })

            print(f"Сообщений в БД: {len(messages)}")

        # === Рендер ===
        html = template.render(chats=chats, messages=messages)
        output_path = os.path.join(OUTPUT_DIR, "index.html")
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)

        print(f"УСПЕХ: Экспорт сохранён → {os.path.abspath(output_path)}")

    except Exception as e:
        print(f"ОШИБКА: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    import asyncio
    asyncio.run(generate_html())