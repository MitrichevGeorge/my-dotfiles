# bot_db.py
from sqlalchemy import create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, Session
from sqlalchemy import String, Boolean
from typing import Any

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    username: Mapped[str] = mapped_column(String(100), nullable=True)
    agree: Mapped[bool] = mapped_column(Boolean, default=False)
    state: Mapped[str] = mapped_column(String(50), default="idle")

engine = create_engine(
    "sqlite:///users.db",
    echo=False,
    connect_args={
        "check_same_thread": False,
    }
)

with engine.connect() as conn:
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    conn.execute("PRAGMA foreign_keys=ON;")

Base.metadata.create_all(engine)

def add_user(tg_id: int, name: str, username: str = None, state: str = "idle"):
    with Session(engine) as session:
        user = session.get(User, tg_id)
        if user:
            user.name = name
            user.username = username
            user.state = state
        else:
            session.add(User(id=tg_id, name=name, username=username, state=state))
        session.commit()

def get_user(tg_id: int):
    with Session(engine) as session:
        return session.get(User, tg_id)

# def set_state(tg_id: int, state: str):
#     with Session(engine) as session:
#         user = session.get(User, tg_id)
#         if user:
#             user.state = state
#             session.commit()

# def get_state(tg_id: int) -> str:
#     user = get_user(tg_id)
#     return user.state if user else "idle"

def get_all_users():
    with Session(engine) as session:
        return session.scalars(select(User)).all()

def update_user(tg_id: int, **kwargs: Any):

    with Session(engine) as session:
        user = session.get(User, tg_id)
        if not user:
            user = User(id=tg_id)
            session.add(user)
        
        for key, value in kwargs.items():
            if hasattr(user, key):
                setattr(user, key, value)
            else:
                print(f"Поле {key} не существует в User!")
        
        session.commit()
    return user