from sqlalchemy import create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, Session
from sqlalchemy import String
import json
import atexit
import os

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50))
    username: Mapped[str] = mapped_column(String(50), nullable=True)

    def to_dict(self):
        return {"id": self.id, "name": self.name, "username": self.username}

    @classmethod
    def from_dict(cls, data):
        return cls(id=data["id"], name=data["name"], username=data.get("username"))

# === 2. База ===
engine = create_engine("sqlite:///bot_users.db", echo=False)
Base.metadata.create_all(engine)

# === 3. Пути к файлам ===
DB_FILE = "bot_users.db"
BACKUP_FILE = "bot_users_backup.json"

# === 4. Загрузка из JSON при старте (если БД пустая) ===
def load_from_backup_if_needed():
    with Session(engine) as session:
        if session.scalar(select(User.id).limit(1)) is None:  # БД пустая?
            if os.path.exists(BACKUP_FILE):
                print("БД пустая → загружаем из бэкапа")
                with open(BACKUP_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                session.add_all([User.from_dict(u) for u in data])
                session.commit()

load_from_backup_if_needed()

# === 5. Автосохранение в JSON при выходе ===
def save_to_backup():
    with Session(engine) as session:
        users = session.scalars(select(User)).all()
        with open(BACKUP_FILE, "w", encoding="utf-8") as f:
            json.dump([u.to_dict() for u in users], f, ensure_ascii=False, indent=2)
    print(f"Данные сохранены в {BACKUP_FILE}")

atexit.register(save_to_backup)  # ← ВОЛШЕБНАЯ СТРОКА

# === 6. Простые функции для бота ===
def add_or_update_user(tg_id: int, name: str, username: str = None):
    with Session(engine) as session:
        user = session.get(User, tg_id)
        if user:
            user.name = name
            user.username = username
        else:
            user = User(id=tg_id, name=name, username=username)
            session.add(user)
        session.commit()

def get_user(tg_id: int):
    with Session(engine) as session:
        return session.get(User, tg_id)

def get_all_users():
    with Session(engine) as session:
        return session.scalars(select(User)).all()