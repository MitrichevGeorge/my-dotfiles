import asyncio
import os
import logging
from pathlib import Path
from telegram import Update
from telegram.ext import Application, ContextTypes, MessageHandler, CommandHandler, filters
from telegram.error import TimedOut, NetworkError

# ------------------- ЛОГИ -------------------
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)

# ------------------- КОНФИГ -------------------
load_dotenv()
BOT_TOKEN = os.getenv("W_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID") or 0)
BASE_DIR = Path(__file__).parent
MEDIA_DIR = BASE_DIR / "media"
MEDIA_DIR.mkdir(exist_ok=True)
(AVATARS_DIR := MEDIA_DIR / "avatars").mkdir(exist_ok=True)
avatar_cache = {}
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50 МБ

# ------------------- ФИКСЫ -------------------
async def safe_download(file, path: Path, max_size=MAX_FILE_SIZE):
    if file.file_size and file.file_size > max_size:
        logger.warning(f"Файл {path.name} слишком большой ({file.file_size} байт)")
        return None
    try:
        await file.download_to_drive(custom_path=str(path))
        return str(path)
    except Exception as e:
        logger.error(f"Не удалось скачать {path}: {e}")
        return None

async def download_avatar(user, bot):
    if not user or user.id in avatar_cache:
        return avatar_cache.get(user.id)

    try:
        photos = await bot.get_user_profile_photos(user.id, limit=1)
        if photos.total_count == 0:
            return None
        file = photos.photos[0][-1]
        path = AVATARS_DIR / f"{user.id}.jpg"
        result = await safe_download(file, path, max_size=5*1024*1024)
        avatar_cache[user.id] = result
        return result
    except Exception as e:
        logger.error(f"Avatar error {user.id}: {e}")
        return None

@rate_limit(calls=5, period=1)  # 5 сообщений в секунду от одного юзера
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    if not msg or not msg.from_user:
        return

    try:
        media_path = None
        if msg.photo:
            file = msg.photo[-1]
            media_path = await safe_download(file.get_file(), MEDIA_DIR / f"{msg.message_id}.jpg")
        elif msg.document and msg.document.mime_type.startswith(("image/", "video/")):
            file = msg.document
            ext = Path(file.file_name).suffix or ".bin"
            media_path = await safe_download(file.get_file(), MEDIA_DIR / f"{msg.message_id}{ext}")

        avatar_path = await download_avatar(msg.from_user, context.bot)
        await save_message(msg, media_path=media_path, avatar_path=avatar_path)
    except Exception as e:
        logger.exception(f"handle_message crash: {e}")

async def handle_delete(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Telegram присылает edited_message с delete_date
    msg = update.edited_message or update.message
    if msg and getattr(msg, "delete_date", None):
        try:
            await save_message(msg, is_deleted=True)
        except Exception as e:
            logger.error(f"delete handler error: {e}")

async def export_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.effective_user or update.effective_user.id != ADMIN_ID:
        return
    await update.message.reply_text("Генерирую HTML…")
    try:
        html_path = BASE_DIR / "export" / "index.html"
        html_path.parent.mkdir(exist_ok=True)
        await asyncio.to_thread(generate_html)  # не блокируем event-loop
        await update.message.reply_document(
            document=open(html_path, "rb"),
            filename="chats.html",
            caption="Чаты (включая удалённые)"
        )
    except Exception as e:
        logger.exception("Export failed")
        await update.message.reply_text(f"Ошибка: {e}")

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logger.error(msg="Exception while handling an update:", exc_info=context.error)
    if isinstance(context.error, (TimedOut, NetworkError)):
        await asyncio.sleep(5)  # авто-ребут при сетевых ошибках

def main():
    app = Application.builder().token(BOT_TOKEN).build()

    # 1. Сообщения
    app.add_handler(MessageHandler(filters.ALL & ~filters.COMMAND, handle_message), group=0)
    # 2. Удаления
    app.add_handler(MessageHandler(filters.UpdateType.EDITED_MESSAGE, handle_delete))
    # 3. Команда /export
    app.add_handler(CommandHandler(
        "export",
        export_command,
        filters=filters.User(ADMIN_ID) & filters.ChatType.PRIVATE
    ))
    # 4. Глобальный обработчик ошибок
    app.add_error_handler(error_handler)

    logger.info("Бот запущен")
    app.run_polling(drop_pending_updates=True,
                   allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    # init_db теперь внутри асинхронного main
    async def init_and_run():
        await init_db()
        main()
    asyncio.run(init_and_run())