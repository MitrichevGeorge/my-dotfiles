# bot.py
from telegram import Update
from telegram.ext import (
    Application,
    ContextTypes,
    MessageHandler,
    CommandHandler,
    filters,
)
import asyncio
import os
from db import init_db, save_message
from dotenv import load_dotenv
from html_generator import generate_html
import logging

load_dotenv()
BOT_TOKEN = os.getenv("W_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID")) if os.getenv("ADMIN_ID") else None

MEDIA_DIR = "media"
os.makedirs(MEDIA_DIR, exist_ok=True)
os.makedirs(f"{MEDIA_DIR}/avatars", exist_ok=True)

# Кэш аватаров
avatar_cache = {}

# Логирование
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def download_avatar(user, bot):
    if not user or user.id in avatar_cache:
        return avatar_cache.get(user.id)

    try:
        photos = await bot.get_user_profile_photos(user.id, limit=1)
        if photos.total_count > 0:
            file = await photos.photos[0][-1].get_file()
            path = f"{MEDIA_DIR}/avatars/{user.id}.jpg"
            await file.download_to_drive(path)
            avatar_cache[user.id] = path
            return path
    except Exception as e:
        logger.warning(f"Ошибка аватара {user.id}: {e}")
    return None


async def global_logger(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Логирует ВСЁ, но использует ТОЛЬКО совместимые с save_message() параметры.
    """
    logger.info(f"Апдейт: {type(update).__name__} | ID: {update.update_id}")

    # === СООБЩЕНИЯ (обычные, с медиа, команды) ===
    if update.message:
        msg = update.message
        if not msg.from_user:
            return

        # Логируем команды в консоль, но не мешаем
        if msg.text and msg.text.startswith("/"):
            logger.info(f"Команда: {msg.text} от {msg.from_user.id}")
            # НЕ вызываем save_message с is_command — его нет!
            return

        # Медиа
        media_path = None
        try:
            if msg.photo:
                file = await msg.photo[-1].get_file()
                media_path = f"{MEDIA_DIR}/{msg.message_id}.jpg"
                await file.download_to_drive(media_path)
            elif msg.document:
                file = await msg.document.get_file()
                filename = msg.document.file_name or "file"
                media_path = f"{MEDIA_DIR}/{msg.message_id}_{filename}"
                await file.download_to_drive(media_path)
            elif msg.video:
                file = await msg.video.get_file()
                media_path = f"{MEDIA_DIR}/{msg.message_id}.mp4"
                await file.download_to_drive(media_path)
        except Exception as e:
            logger.error(f"Ошибка медиа {msg.message_id}: {e}")

        # Аватар
        avatar_path = await download_avatar(msg.from_user, context.bot)

        # Сохраняем — ТОЛЬКО СОВМЕСТИМЫЕ ПАРАМЕТРЫ
        await save_message(
            msg,
            media_path=media_path,
            avatar_path=avatar_path
        )

    # === РЕДАКТИРОВАННЫЕ СООБЩЕНИЯ ===
    elif update.edited_message:
        edited_msg = update.edited_message
        # save_message не принимает is_edited → просто сохраняем как новое
        avatar_path = await download_avatar(edited_msg.from_user, context.bot)
        await save_message(
            edited_msg,
            media_path=None,  # медиа не меняется
            avatar_path=avatar_path
        )
        logger.info(f"Отредактировано: {edited_msg.message_id}")

    # === УДАЛЕНИЕ СООБЩЕНИЯ ===
    elif update.message and update.message.delete_date:
        await save_message(update.message, is_deleted=True)
        logger.info(f"Удалено: {update.message.message_id}")

    # === CALLBACK QUERY (кнопки) ===
    elif update.callback_query:
        cq = update.callback_query
        message = cq.message
        if message and message.from_user:
            avatar_path = await download_avatar(cq.from_user, context.bot)
            # save_message не знает про callback → сохраняем как сообщение
            await save_message(
                message,
                media_path=None,
                avatar_path=avatar_path
            )
        logger.info(f"Callback: {cq.data} от {cq.from_user.id}")


async def export_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    print("=" * 30)  # ← Теперь будет видно!
    print(f"User: {update.effective_user.id}, Chat: {update.effective_chat.type}")

    # ПРАВИЛЬНАЯ ПРОВЕРКА
    if (
        update.effective_user.id != ADMIN_ID
        or update.effective_chat.type != "private"
        or update.message.forward_date is not None  # ← ИСПРАВЛЕНО
    ):
        print("Доступ запрещён или сообщение переслано")
        return

    print("Доступ разрешён — генерируем HTML...")

    await update.message.reply_text("Генерирую экспорт...")
    try:
        await generate_html()
        await update.message.reply_document(
            open("export/index.html", "rb"),
            filename="chats.html",
            caption="Экспорт чатов (включая удалённые)"
        )
        print("HTML отправлен")
    except Exception as e:
        logger.error(f"Ошибка экспорта: {e}")
        await update.message.reply_text("Ошибка.")
        print("Ошибка при генерации")


def main():
    if not BOT_TOKEN or not ADMIN_ID:
        raise ValueError("BOT_TOKEN и ADMIN_ID обязательны")

    app = Application.builder().token(BOT_TOKEN).build()

    # Глобальный логгер — ловит ВСЁ, не блокирует
    app.add_handler(
        MessageHandler(filters.ALL, global_logger, block=False),
        group=0
    )

    # Команда /export
    app.add_handler(
        CommandHandler(
            "export",
            export_command,
            filters=(filters.User(ADMIN_ID) & filters.ChatType.PRIVATE & ~filters.FORWARDED)
        )
    )

    # ←←← Добавляй сюда свои хендлеры: /start, FSM, кнопки и т.д.

    print(f"Бот запущен. Админ ID: {ADMIN_ID}")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    asyncio.run(init_db())
    main()