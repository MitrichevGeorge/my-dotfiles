# bot.py
import asyncio
import os
import logging
from pathlib import Path

from telegram import Update
from telegram.ext import (
    Application,
    ContextTypes,
    CommandHandler,
    MessageHandler,
    filters,
)
from db import init_db, save_message
from dotenv import load_dotenv
from limiter import rate_limit
from html_generator import generate_html

# -------------------------------------------------
# Настройки
# -------------------------------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

load_dotenv()
BOT_TOKEN = os.getenv("W_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID"))

MEDIA_DIR = "media"
AVATAR_DIR = f"{MEDIA_DIR}/avatars"
Path(AVATAR_DIR).mkdir(parents=True, exist_ok=True)

avatar_cache: dict[int, str] = {}

# -------------------------------------------------
# «Middleware» – самый первый хэндлер (group=-1)
# -------------------------------------------------
async def logging_middleware(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Сохраняет каждое сообщение, скачивает медиа и аватар."""
    msg = getattr(update, "message", None)
    if not msg or not msg.from_user:
        return                     # пропускаем всё, что не сообщение

    user = msg.from_user
    try:
        # ---------- медиа ----------
        media_path = None
        if msg.photo:
            file = await msg.photo[-1].get_file()
            media_path = f"{MEDIA_DIR}/{msg.message_id}.jpg"
            await file.download_to_drive(media_path)
        elif msg.document:
            file = await msg.document.get_file()
            name = msg.document.file_name or f"doc_{msg.message_id}"
            media_path = f"{MEDIA_DIR}/{msg.message_id}_{name}"
            await file.download_to_drive(media_path)
        elif msg.video:
            file = await msg.video.get_file()
            media_path = f"{MEDIA_DIR}/{msg.message_id}.mp4"
            await file.download_to_drive(media_path)
        # …добавьте любые другие типы

        # ---------- аватар ----------
        avatar_path = avatar_cache.get(user.id)
        if not avatar_path:
            try:
                photos = await context.bot.get_user_profile_photos(user.id, limit=1)
                if photos.total_count:
                    file = await photos.photos[0][-1].get_file()
                    avatar_path = f"{AVATAR_DIR}/{user.id}.jpg"
                    await file.download_to_drive(avatar_path)
                    avatar_cache[user.id] = avatar_path
            except Exception as e:
                logger.warning(f"Аватар {user.id}: {e}")

        # ---------- БД ----------
        await save_message(
            message=msg,
            media_path=media_path,
            avatar_path=avatar_path,
            is_deleted=False,
        )

        logger.info(
            f"Saved: {user.id=} {msg.message_id=} "
            f"media={'+' if media_path else '-'}"
        )
    except Exception as e:
        logger.error(f"Middleware error: {e}", exc_info=True)

    # **ВАЖНО**: ничего не возвращаем – цепочка продолжается


# -------------------------------------------------
# Команды
# -------------------------------------------------
@rate_limit("command")
async def export_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    await update.message.reply_text("Генерирую страницу…")
    await generate_html()
    await update.message.reply_document(
        open("export/index.html", "rb"),
        filename="chats.html",
        caption="Чаты (включая удалённые)",
    )


# -------------------------------------------------
# main()
# -------------------------------------------------
def main() -> None:
    app = Application.builder().token(BOT_TOKEN).build()

    # 1. Самый первый хэндлер – наш «middleware»
    app.add_handler(MessageHandler(filters.ALL, logging_middleware), group=-1)

    # 2. Обычные команды
    app.add_handler(
        CommandHandler(
            "export",
            export_command,
            filters=(
                filters.User(ADMIN_ID) &
                filters.ChatType.PRIVATE &
                ~filters.FORWARDED
            ),
        )
    )

    # Можно добавить любые другие хэндлеры – они будут работать
    # app.add_handler(CommandHandler("start", start_cmd))

    print(f"Бот запущен… ADMIN_ID={ADMIN_ID}")
    app.run_polling()


if __name__ == "__main__":
    asyncio.run(init_db())
    main()