# bot.py
from telegram import Update
from telegram.ext import Application, ContextTypes, MessageHandler, CommandHandler, filters
from telegram.ext.filters import ALL
import asyncio
import os
from db import init_db, save_message
from dotenv import load_dotenv
from limiter import rate_limit
from html_generator import generate_html

load_dotenv()
BOT_TOKEN = os.getenv("W_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID"))

MEDIA_DIR = "media"
os.makedirs(MEDIA_DIR, exist_ok=True)

# Кэш аватаров
avatar_cache = {}

async def download_avatar(user, bot):
    if not user or user.id in avatar_cache:
        return avatar_cache.get(user.id)

    try:
        photos = await bot.get_user_profile_photos(user.id, limit=1)
        if photos.total_count > 0:
            file = await photos.photos[0][-1].get_file()
            path = f"{MEDIA_DIR}/avatars/{user.id}.jpg"
            os.makedirs(os.path.dirname(path), exist_ok=True)
            await file.download_to_drive(path)
            avatar_cache[user.id] = path
            return path
    except Exception as e:
        print(f"Ошибка аватара {user.id}: {e}")
    return None

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    if not msg or not msg.from_user:
        return

    # Медиа
    media_path = None
    if msg.photo:
        file = await msg.photo[-1].get_file()
        media_path = f"{MEDIA_DIR}/{msg.message_id}.jpg"
        await file.download_to_drive(media_path)
    elif msg.document:
        file = await msg.document.get_file()
        media_path = f"{MEDIA_DIR}/{msg.message_id}_{msg.document.file_name}"
        await file.download_to_drive(media_path)

    # Аватар
    avatar_path = await download_avatar(msg.from_user, context.bot)

    await save_message(msg, media_path=media_path, avatar_path=avatar_path)

async def handle_delete(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message and update.message.delete_date:
        await save_message(update.message, is_deleted=True)

# @rate_limit("command")
async def export_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    print("becue")
    await update.message.reply_text("Генерирую страницу...")
    await generate_html()
    await update.message.reply_document(
        open("export/index.html", "rb"),
        filename="chats.html",
        caption="Чаты (включая удалённые)"
    )

def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(
        MessageHandler(filters.ALL, handle_message, block=False)
    )

    app.add_handler(
        MessageHandler(None, handle_delete, block=False)
    )

    app.add_handler(
        CommandHandler(
            "export",
            export_command,
            filters=(
                filters.User(ADMIN_ID)
                & filters.ChatType.PRIVATE
                & ~filters.FORWARDED
            )
        )
    )

    print(ADMIN_ID)

    print("Бот запущен...")
    app.run_polling()

if __name__ == "__main__":
    asyncio.run(init_db())
    main()