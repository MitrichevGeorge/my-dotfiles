# bot.py
import asyncio
import os
import logging
from datetime import datetime
from pathlib import Path

from telegram import Update
from telegram.ext import (
    Application,
    ContextTypes,
    CommandHandler,
    filters,
    BaseHandler,
    CallbackContext,
)
from telegram.ext.filters import ALL
from db import init_db, save_message
from dotenv import load_dotenv
from limiter import rate_limit
from html_generator import generate_html

# === Настройка логирования ===
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# === Загрузка переменных ===
load_dotenv()
BOT_TOKEN = os.getenv("W_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID"))

MEDIA_DIR = "media"
AVATAR_DIR = f"{MEDIA_DIR}/avatars"
Path(AVATAR_DIR).mkdir(parents=True, exist_ok=True)

# Кэш аватаров
avatar_cache = {}


# === Middleware для логирования и сохранения сообщений ===
class LoggingMiddleware:
    async def __call__(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        handler: BaseHandler,
        **kwargs,
    ):
        # Пропускаем, если это не сообщение
        if not update.message:
            return await handler(update, context)

        msg = update.message
        user = msg.from_user
        if not user:
            return await handler(update, context)

        try:
            # === Скачивание медиа ===
            media_path = None
            if msg.photo:
                file = await msg.photo[-1].get_file()
                media_path = f"{MEDIA_DIR}/{msg.message_id}.jpg"
                await file.download_to_drive(media_path)
            elif msg.document:
                file = await msg.document.get_file()
                file_name = msg.document.file_name or f"doc_{msg.message_id}"
                media_path = f"{MEDIA_DIR}/{msg.message_id}_{file_name}"
                await file.download_to_drive(media_path)
            elif msg.video:
                file = await msg.video.get_file()
                media_path = f"{MEDIA_DIR}/{msg.message_id}.mp4"
                await file.download_to_drive(media_path)
            # Добавь другие типы при необходимости

            # === Скачивание аватара (с кэшем) ===
            avatar_path = None
            if user.id not in avatar_cache:
                try:
                    photos = await context.bot.get_user_profile_photos(user.id, limit=1)
                    if photos.total_count > 0:
                        file = await photos.photos[0][-1].get_file()
                        avatar_path = f"{AVATAR_DIR}/{user.id}.jpg"
                        await file.download_to_drive(avatar_path)
                        avatar_cache[user.id] = avatar_path
                except Exception as e:
                    logger.warning(f"Не удалось скачать аватар {user.id}: {e}")
            else:
                avatar_path = avatar_cache[user.id]

            # === Сохранение в БД ===
            await save_message(
                message=msg,
                media_path=media_path,
                avatar_path=avatar_path,
                is_deleted=False,
            )

            # Логируем в консоль/файл
            logger.info(
                f"Сообщение сохранено: {user.id=} {msg.message_id=} "
                f"text='{msg.text or msg.caption or '[медиа]'}' "
                f"media={'+' if media_path else '-'}"
            )

        except Exception as e:
            logger.error(f"Ошибка в middleware: {e}", exc_info=True)

        # === Передаём управление дальше (в хэндлеры) ===
        return await handler(update, context)


# === Команда /export ===
@rate_limit("command")
async def export_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return

    await update.message.reply_text("Генерирую страницу...")
    await generate_html()
    await update.message.reply_document(
        open("export/index.html", "rb"),
        filename="chats.html",
        caption="Чаты (включая удалённые)"
    )


# === Middleware через pre_process_update ===
async def logging_middleware(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message:
        return  # Пропускаем не-сообщения

    msg = update.message
    user = msg.from_user
    if not user:
        return

    try:
        # === Скачивание медиа ===
        media_path = None
        if msg.photo:
            file = await msg.photo[-1].get_file()
            media_path = f"{MEDIA_DIR}/{msg.message_id}.jpg"
            await file.download_to_drive(media_path)
        elif msg.document:
            file = await msg.document.get_file()
            file_name = msg.document.file_name or f"doc_{msg.message_id}"
            media_path = f"{MEDIA_DIR}/{msg.message_id}_{file_name}"
            await file.download_to_drive(media_path)
        elif msg.video:
            file = await msg.video.get_file()
            media_path = f"{MEDIA_DIR}/{msg.message_id}.mp4"
            await file.download_to_drive(media_path)

        # === Аватар ===
        avatar_path = None
        if user.id not in avatar_cache:
            try:
                photos = await context.bot.get_user_profile_photos(user.id, limit=1)
                if photos.total_count > 0:
                    file = await photos.photos[0][-1].get_file()
                    avatar_path = f"{AVATAR_DIR}/{user.id}.jpg"
                    await file.download_to_drive(avatar_path)
                    avatar_cache[user.id] = avatar_path
            except Exception as e:
                logger.warning(f"Аватар {user.id}: {e}")
        else:
            avatar_path = avatar_cache[user.id]

        # === Сохранение ===
        await save_message(
            message=msg,
            media_path=media_path,
            avatar_path=avatar_path,
            is_deleted=False,
        )

        logger.info(f"Сохранено: {user.id=} {msg.message_id=} media={'+' if media_path else '-'}")

    except Exception as e:
        logger.error(f"Middleware error: {e}", exc_info=True)

    # НИЧЕГО НЕ ВОЗВРАЩАЕМ — цепочка продолжается

# === Основная функция ===
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    # === Middleware ===
    app.process_update = logging_middleware

    # === Хэндлеры ===
    app.add_handler(
        CommandHandler(
            "export",
            export_command,
            filters=filters.User(ADMIN_ID) & filters.ChatType.PRIVATE & ~filters.FORWARDED
        )
    )

    print(f"Бот запущен... ADMIN_ID={ADMIN_ID}")
    app.run_polling()

if __name__ == "__main__":
    asyncio.run(init_db())
    main()