# bot.py
import asyncio
import json
import os
import logging
from datetime import datetime
from telegram import Update, Bot
from telegram.ext import (
    ContextTypes, CommandHandler, CallbackQueryHandler,
    ConversationHandler, filters
)
from telegram.error import TimedOut, NetworkError
from db import init_db, save_message
from html_generator import generate_html
from dotenv import load_dotenv

load_dotenv()
BOT_TOKEN = os.getenv("W_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID")) if os.getenv("ADMIN_ID") else None

MEDIA_DIR = "media"
os.makedirs(MEDIA_DIR, exist_ok=True)
os.makedirs(f"{MEDIA_DIR}/avatars", exist_ok=True)

avatar_cache = {}
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# === Бот ===
bot = Bot(token=BOT_TOKEN)

# === Кэш апдейтов ===
last_update_id = 0

# === Хранилище контекста (как в PTB) ===
job_queue = None
application = None


# ==============================
# АВАТАРЫ
# ==============================
async def download_avatar(user, bot):
    if not user or user.id in avatar_cache:
        return avatar_cache.get(user.id)

    try:
        photos = await bot.get_user_profile_photos(user.id, limit=1)
        if photos.total_count > 0:
            file = await photos.photos[0][-1].get_file()
            path = f"{MEDIA_DIR}/avatars/{user.id}.jpg"
            await file.download_to_drive(path)
            avatar_cache[user.id] = path
            return path
    except Exception as e:
        logger.warning(f"Avatar error {user.id}: {e}")
    return None


# ==============================
# MIDDLEWARE: СНАЧАЛА СОХРАНЯЕМ
# ==============================
async def middleware_save(update: Update):
    """СНАЧАЛА — сохраняем в БД. Это middleware."""
    logger.info(f"MIDDLEWARE: {type(update).__name__} | ID: {update.update_id}")

    # --- СООБЩЕНИЯ ---
    if update.message:
        msg = update.message
        if not msg.from_user:
            return

        media_path = None
        try:
            if msg.photo:
                file = await msg.photo[-1].get_file()
                media_path = f"{MEDIA_DIR}/{msg.message_id}.jpg"
                await file.download_to_drive(media_path)
            elif msg.document:
                file = await msg.document.get_file()
                fname = msg.document.file_name or "file"
                media_path = f"{MEDIA_DIR}/{msg.message_id}_{fname}"
                await file.download_to_drive(media_path)
            elif msg.video:
                file = await msg.video.get_file()
                media_path = f"{MEDIA_DIR}/{msg.message_id}.mp4"
                await file.download_to_drive(media_path)
        except Exception as e:
            logger.error(f"Media error: {e}")

        avatar_path = await download_avatar(msg.from_user, bot)
        await save_message(msg, media_path=media_path, avatar_path=avatar_path)

    # --- РЕДАКТИРОВАНИЕ ---
    elif update.edited_message:
        msg = update.edited_message
        avatar_path = await download_avatar(msg.from_user, bot)
        await save_message(msg, media_path=None, avatar_path=avatar_path)

    # --- УДАЛЕНИЕ ---
    elif update.message and update.message.delete_date:
        await save_message(update.message, is_deleted=True)

    # --- CALLBACK ---
    elif update.callback_query:
        cq = update.callback_query
        msg = cq.message
        if msg and msg.from_user:
            avatar_path = await download_avatar(cq.from_user, bot)
            await save_message(msg, media_path=None, avatar_path=avatar_path)


# ==============================
# ХЕНДЛЕРЫ (ПОСЛЕ middleware)
# ==============================
async def export_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    print("=" * 50)
    print(f"EXPORT: User {update.effective_user.id}, Chat: {update.effective_chat.type}")

    if (
        update.effective_user.id != ADMIN_ID
        or update.effective_chat.type != "private"
        or update.message.forward_date is not None
    ):
        print("Доступ запрещён")
        return

    print("Генерация HTML...")
    await update.message.reply_text("Генерирую экспорт...")

    try:
        await generate_html()
        await update.message.reply_document(
            open("export/index.html", "rb"),
            filename="chats.html",
            caption="Экспорт чатов"
        )
        print("HTML отправлен")
    except Exception as e:
        logger.error(f"Export error: {e}")
        await update.message.reply_text("Ошибка.")
        print("Ошибка")


# ==============================
# ОСНОВНОЙ ЦИКЛ
# ==============================
async def main_loop():
    global last_update_id

    # === Инициализация ===
    await init_db()
    me = await bot.get_me()
    logger.info(f"Бот запущен: @{me.username}")

    # === Хендлеры (как в PTB) ===
    handlers = [
        CommandHandler(
            "export",
            export_command,
            filters=(filters.User(ADMIN_ID) & filters.ChatType.PRIVATE & ~filters.FORWARDED)
        ),
        # ← Добавляй сюда свои: /start, FSM, кнопки
    ]

    offset = last_update_id

    while True:
        try:
            updates = await bot.get_updates(
                offset=offset,
                timeout=30,
                allowed_updates=Update.ALL_TYPES
            )

            for update in updates:
                update_id = update.update_id
                if update_id > last_update_id:
                    last_update_id = update_id

                # === 1. MIDDLEWARE: СНАЧАЛА СОХРАНЯЕМ ===
                try:
                    await middleware_save(update)
                except Exception as e:
                    logger.error(f"Middleware error: {e}")

                # === 2. ПЕРЕДАЁМ В ХЕНДЛЕРЫ ===
                context = ContextTypes.DEFAULT_TYPE()
                context.bot = bot
                context.update_queue = asyncio.Queue()
                context.job_queue = job_queue
                context.user_data = {}
                context.chat_data = {}
                context.bot_data = {}

                for handler in handlers:
                    try:
                        check = await handler.check_update(update)
                        if check is True or (isinstance(check, dict) and check):
                            await handler.handle_update(update, context.application, check)
                            break  # Один хендлер — один апдейт
                    except Exception as e:
                        logger.error(f"Handler error: {e}")

                offset = update_id + 1

        except (TimedOut, NetworkError) as e:
            logger.warning(f"Network error: {e}. Retry...")
            await asyncio.sleep(5)
        except Exception as e:
            logger.error(f"Fatal error: {e}")
            await asyncio.sleep(5)


# ==============================
# ЗАПУСК
# ==============================
if __name__ == "__main__":
    if not BOT_TOKEN or not ADMIN_ID:
        raise ValueError("BOT_TOKEN и ADMIN_ID обязательны")

    try:
        asyncio.run(main_loop())
    except KeyboardInterrupt:
        logger.info("Бот остановлен")