            filters=(filters.User(ADMIN_ID) & filters.ChatType.PRIVATE & ~filters.FORWARDED)
