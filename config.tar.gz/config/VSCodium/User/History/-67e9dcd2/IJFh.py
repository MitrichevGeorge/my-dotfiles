# bot.py
from telegram import Update
from telegram.ext import (
    Application,
    ContextTypes,
    CommandHandler,
    filters,
    BaseMiddleware,
)
from telegram.ext.filters import ALL
import asyncio
import os
from db import init_db, save_message
from dotenv import load_dotenv
from html_generator import generate_html
import logging

load_dotenv()
BOT_TOKEN = os.getenv("W_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID")) if os.getenv("ADMIN_ID") else None

MEDIA_DIR = "media"
os.makedirs(MEDIA_DIR, exist_ok=True)
os.makedirs(f"{MEDIA_DIR}/avatars", exist_ok=True)

# Кэш аватаров
avatar_cache = {}

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def download_avatar(user, bot):
    """Скачивает аватар пользователя и кэширует путь."""
    if not user or user.id in avatar_cache:
        return avatar_cache.get(user.id)

    try:
        photos = await bot.get_user_profile_photos(user.id, limit=1)
        if photos.total_count > 0:
            file = await photos.photos[0][-1].get_file()
            path = f"{MEDIA_DIR}/avatars/{user.id}.jpg"
            await file.download_to_drive(path)
            avatar_cache[user.id] = path
            return path
    except Exception as e:
        logger.warning(f"Ошибка загрузки аватара {user.id}: {e}")
    return None


class GlobalUpdateLoggerMiddleware(BaseMiddleware):
    """Логирует ВСЕ апдейты до их обработки хендлерами."""

    async def preprocess(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        # Логируем факт получения апдейта
        update_type = type(update).__name__
        update_id = update.update_id
        logger.info(f"Получен апдейт: {update_type} | ID: {update_id}")

        # Обработка сообщений (включая медиа, команды, редактирования)
        if update.message:
            msg = update.message
            user = msg.from_user
            chat = msg.chat

            # Скачивание медиа
            media_path = None
            if msg.photo:
                file = await msg.photo[-1].get_file()
                media_path = f"{MEDIA_DIR}/{msg.message_id}.jpg"
                try:
                    await file.download_to_drive(media_path)
                except Exception as e:
                    logger.error(f"Ошибка скачивания фото {msg.message_id}: {e}")
            elif msg.document:
                file = await msg.document.get_file()
                ext = os.path.splitext(msg.document.file_name)[1] or ""
                media_path = f"{MEDIA_DIR}/{msg.message_id}_{msg.document.file_name}"
                try:
                    await file.download_to_drive(media_path)
                except Exception as e:
                    logger.error(f"Ошибка скачивания документа {msg.message_id}: {e}")
            elif msg.video:
                file = await msg.video.get_file()
                media_path = f"{MEDIA_DIR}/{msg.message_id}.mp4"
                try:
                    await file.download_to_drive(media_path)
                except Exception as e:
                    logger.error(f"Ошибка скачивания видео {msg.message_id}: {e}")

            # Аватар
            avatar_path = await download_avatar(user, context.bot)

            # Сохранение в БД
            await save_message(
                msg,
                media_path=media_path,
                avatar_path=avatar_path,
                is_edited=False,
                is_deleted=False,
            )

        # Обработка редактирования сообщения
        elif update.edited_message:
            edited_msg = update.edited_message
            await save_message(
                edited_msg,
                is_edited=True,
                is_deleted=False,
            )

        # Обработка удаления сообщения
        elif update.message and update.message.delete_date:
            await save_message(
                update.message,
                is_deleted=True,
            )

        # Callback Query (нажатия на кнопки)
        elif update.callback_query:
            cq = update.callback_query
            user = cq.from_user
            message = cq.message
            avatar_path = await download_avatar(user, context.bot)
            await save_message(
                message,
                callback_data=cq.data,
                user=user,
                avatar_path=avatar_path,
                is_callback=True,
            )

        # Другие типы апдейтов (можно расширить)
        # update.channel_post, update.poll, update.chat_member, и т.д.

        # Возвращаем True — апдейт передаётся дальше
        return True


async def export_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /export — только для админа в ЛС."""
    if (
        update.effective_user.id != ADMIN_ID
        or update.effective_chat.type != "private"
        or update.message.forward_date
    ):
        return

    await update.message.reply_text("Генерирую HTML-страницу чата...")
    try:
        await generate_html()
        await update.message.reply_document(
            open("export/index.html", "rb"),
            filename="chats.html",
            caption="Экспорт чатов (включая удалённые и отредактированные)"
        )
    except Exception as e:
        logger.error(f"Ошибка при экспорте: {e}")
        await update.message.reply_text("Ошибка при генерации экспорта.")


def main():
    if not BOT_TOKEN:
        raise ValueError("BOT_TOKEN не указан в .env")
    if not ADMIN_ID:
        raise ValueError("ADMIN_ID не указан в .env")

    app = Application.builder().token(BOT_TOKEN).concurrent_updates(True).build()

    # === Глобальный логгер через Middleware ===
    app.add_middleware(GlobalUpdateLoggerMiddleware())

    # === Команда /export ===
    app.add_handler(
        CommandHandler(
            "export",
            export_command,
            filters=(
                filters.User(ADMIN_ID)
                & filters.ChatType.PRIVATE
                & ~filters.FORWARDED
            ),
        )
    )

    # === Здесь добавляйте ВСЕ остальные хендлеры бота ===
    # Например:
    # app.add_handler(CommandHandler("start", start))
    # app.add_handler(ConversationHandler(...))
    # app.add_handler(CallbackQueryHandler(button_handler))

    print(f"Бот запущен. Админ: {ADMIN_ID}")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    asyncio.run(init_db())
    main()