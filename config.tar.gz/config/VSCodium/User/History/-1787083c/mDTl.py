# test_bot.py
from telegram.ext import Application, CommandHandler, filters

BOT_TOKEN = "ТОКЕН_ИЗ_BOTFATHER"  # ← ВСТАВЬ СЮДА ПРЯМО

async def export_command(update, context):
    print("КОМАНДА СРАБОТАЛА!")
    await update.message.reply_text("Работает!")

app = Application.builder().token(BOT_TOKEN).build()

app.add_handler(CommandHandler(
    "export",
    export_command,
    filters=filters.ChatType.PRIVATE
))

print("Тестовый бот запущен...")
app.run_polling()