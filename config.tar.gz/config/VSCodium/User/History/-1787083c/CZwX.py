# bot.py
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes, filters

BOT_TOKEN = "8315969141:AAGd4c6hNIZjD0eSEa3KqUrkexEVAiW1VSE"

async def export_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    print("h")  # ← ДОЛЖНО ВЫВЕСТИСЬ
    await update.message.reply_text("Генерирую страницу...")

def main():
    app = Application.builder().token(BOT_TOKEN).build()

    # ← РАБОЧИЙ ХЭНДЛЕР (только в личке)
    app.add_handler(CommandHandler(
        "export",
        export_command,
        filters=filters.ChatType.PRIVATE
    ))

    print("Бот запущен...")
    app.run_polling()

if __name__ == "__main__":
    main()