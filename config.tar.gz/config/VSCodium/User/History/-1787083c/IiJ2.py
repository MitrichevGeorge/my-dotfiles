# bot.py
# bot.py
from telegram import Update
from telegram.ext import Application, ContextTypes, MessageHandler, CommandHandler, filters
from telegram.ext.filters import ALL
import asyncio
import os
from db import init_db, save_message
from dotenv import load_dotenv
from limiter import rate_limit
from html_generator import generate_html

load_dotenv()
BOT_TOKEN = os.getenv("W_TOKEN")
ADMIN_ID = os.getenv("ADMIN_ID")


async def export_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    print("h")  # ← ДОЛЖНО ВЫВЕСТИСЬ
    await update.message.reply_text("Генерирую страницу...")

def main():
    app = Application.builder().token(BOT_TOKEN).build()

    # ← РАБОЧИЙ ХЭНДЛЕР (только в личке)
    app.add_handler(CommandHandler(
        "export",
        export_command,
        filters=filters.ChatType.PRIVATE
    ))

    print("Бот запущен...")
    app.run_polling()

if __name__ == "__main__":
    main()