from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.requests import Request
from typing import Dict, Set
import asyncio
from datetime import datetime

app = FastAPI()
templates = Jinja2Templates(directory=".")

# Хранилище для дистрибьюторов и клиентов
distributors: Dict[str, WebSocket] = {}  # id -> WebSocket дистрибьютора
clients: Dict[str, Set[WebSocket]] = {}  # id -> множество клиентов
queues: Dict[str, asyncio.Queue] = {}  # id -> очередь сообщений для дистрибьютора

@app.get("/in/{dist_id}", response_class=HTMLResponse)
async def distributor_page(request: Request, dist_id: str):
    return templates.TemplateResponse("index.html", {"request": request, "dist_id": dist_id, "endpoint": f"/in/{dist_id}"})

@app.get("/list", response_class=HTMLResponse)
async def list_page(request: Request):
    return templates.TemplateResponse("list.html", {"time" : str(datetime.now())})

@app.get("/cl/{dist_id}", response_class=HTMLResponse)
async def client_page(request: Request, dist_id: str):
    return templates.TemplateResponse("index.html", {"request": request, "dist_id": dist_id, "endpoint": f"/cl/{dist_id}"})

@app.websocket("/in/{dist_id}")
async def distributor_endpoint(websocket: WebSocket, dist_id: str):
    await websocket.accept()
    if dist_id in distributors:
        await websocket.close(code=4000, reason="Distributor ID already in use")
        return

    distributors[dist_id] = websocket
    clients[dist_id] = set()
    queues[dist_id] = asyncio.Queue()

    try:
        # Запускаем задачу для обработки очереди сообщений
        queue_task = asyncio.create_task(process_queue(dist_id))
        while True:
            message = await websocket.receive_text()
            # Рассылаем сообщение всем клиентам
            for client in clients.get(dist_id, set()):
                await client.send_text(message)
    except WebSocketDisconnect:
        pass
    finally:
        # Очистка при отключении дистрибьютора
        distributors.pop(dist_id, None)
        queue_task.cancel()
        queues.pop(dist_id, None)
        for client in clients.get(dist_id, set()):
            await client.close(code=4000, reason="Distributor disconnected")
        clients.pop(dist_id, None)

@app.websocket("/cl/{dist_id}")
async def client_endpoint(websocket: WebSocket, dist_id: str):
    await websocket.accept()
    if dist_id not in distributors:
        await websocket.close(code=4000, reason="Distributor not found")
        return

    clients[dist_id].add(websocket)
    try:
        while True:
            message = await websocket.receive_text()
            # Добавляем сообщение клиента в очередь дистрибьютора
            await queues[dist_id].put(message)
    except WebSocketDisconnect:
        pass
    finally:
        clients[dist_id].discard(websocket)

async def process_queue(dist_id: str):
    """Обрабатывает очередь сообщений для дистрибьютора"""
    queue = queues.get(dist_id)
    distributor = distributors.get(dist_id)
    if not queue or not distributor:
        return
    try:
        while True:
            message = await queue.get()
            await distributor.send_text(message)
            queue.task_done()
    except asyncio.CancelledError:
        pass
