# db.py
import aiosqlite
import asyncio

DB_NAME = "bot_chats.db"

async def init_db():
    async with aiosqlite.connect(DB_NAME) as db:

        await db.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY,
                chat_id INTEGER,
                chat_title TEXT,
                message_id INTEGER,
                user_id INTEGER,
                username TEXT,
                first_name TEXT,
                text TEXT,
                date TEXT,
                is_deleted INTEGER DEFAULT 0,
                media_path TEXT,
                avatar_path TEXT  -- НОВОЕ
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS chats (
                chat_id INTEGER PRIMARY KEY,
                title TEXT,
                type TEXT
            )
        """)
        await db.commit()

async def save_message(msg, is_deleted=False, media_path=None):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("""
            INSERT OR REPLACE INTO messages 
            (chat_id, chat_title, message_id, user_id, username, first_name, text, date, is_deleted, media_path)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            msg.chat.id,
            msg.chat.title or f"User {msg.from_user.id}",
            msg.message_id,
            msg.from_user.id if msg.from_user else None,
            msg.from_user.username if msg.from_user else None,
            msg.from_user.first_name if msg.from_user else None,
            msg.text or msg.caption or "[Media]",
            msg.date.isoformat(),
            1 if is_deleted else 0,
            media_path
        ))
        await db.execute("""
            INSERT OR IGNORE INTO chats (chat_id, title, type)
            VALUES (?, ?, ?)
        """, (msg.chat.id, msg.chat.title or "Private", str(msg.chat.type)))
        await db.commit()