import asyncio
import socks
from telethon import TelegramClient, errors
from telethon.sessions import StringSession
from pars2 import getproxy_cached
from random import randint

pr = getproxy_cached()  # список dict с ip и port

API_ID = 24562157
API_HASH = "6ec6241e31f57d6cbe7e82e6258b2668"

CONCURRENCY = 50     # ⚡ сильно увеличено
OP_TIMEOUT = 8        # меньше таймаут = быстрее отбрасывает мёртвые
CONNECT_RETRIES = 1   # только одна попытка подключения

def make_client_for_proxy(proxy_tuple):
    z = randint(1, 3)
    if z == 1:
        device_model, system_version, app_version = "Pixel 7", "Android 14", "9.0.0"
    elif z == 2:
        device_model, system_version, app_version = "HP Pavilion P9", "Windows 11", "3.2.0"
    else:
        device_model, system_version, app_version = "Ipad Air 12", "IOS 13", "9.12.3"

    # сессия в памяти
    session = StringSession()
    client = TelegramClient(
        session=session,
        api_id=API_ID,
        api_hash=API_HASH,
        proxy=proxy_tuple,
        device_model=device_model,
        system_version=system_version,
        app_version=app_version,
        lang_code="ru",
        system_lang_code="ru-RU",
        connection_retries=CONNECT_RETRIES,  # ⚡ не пытаться переподключаться
        retry_delay=0,                      # ⚡ сразу падать
        request_retries=1,                  # ⚡ не повторять RPC-запрос
        timeout=OP_TIMEOUT,                 # общая сетевая граница
        use_ipv6=False                      # ⚡ ускоряет SOCKS
    )
    return client

async def try_proxy(q, phone, sem: asyncio.Semaphore, timeout: int):
    ip = q.get("ip")
    port_s = q.get("port") or ""
    try:
        port = int(port_s)
    except (ValueError, TypeError):
        print(f"[{ip}:{port_s}] ❌ bad port")
        return {"proxy": f"{ip}:{port_s}", "ok": False, "reason": "bad_port"}

    proxy_tuple = (socks.SOCKS5, ip, port)

    async with sem:
        client = make_client_for_proxy(proxy_tuple)
        try:
            await asyncio.wait_for(client.connect(), timeout=timeout)
        except Exception as e:
            print(f"[{ip}:{port}] ❌ connect: {type(e).__name__}: {e}")
            await safe_disconnect(client)
            return {"proxy": f"{ip}:{port}", "ok": False, "reason": f"connect:{e}"}

        try:
            await asyncio.wait_for(client.send_code_request(phone), timeout=timeout)
            print(f"[{ip}:{port}] ✅ OK")
            return {"proxy": f"{ip}:{port}", "ok": True}
        except asyncio.TimeoutError:
            print(f"[{ip}:{port}] ⏱ timeout send_code_request")
            return {"proxy": f"{ip}:{port}", "ok": False, "reason": "send_timeout"}
        except errors.RPCError as e:
            print(f"[{ip}:{port}] 🚫 RPCError: {e.__class__.__name__}: {e}")
            return {"proxy": f"{ip}:{port}", "ok": False, "reason": f"rpc:{e}"}
        except Exception as e:
            print(f"[{ip}:{port}] 💥 other: {type(e).__name__}: {e}")
            return {"proxy": f"{ip}:{port}", "ok": False, "reason": f"other:{e}"}
        finally:
            await safe_disconnect(client)

async def safe_disconnect(client):
    try:
        if client and not client.is_disconnected():
            await client.disconnect()
    except Exception:
        pass

async def main():
    if not pr:
        print("Нет прокси")
        return

    phone = input("номер: ").strip()
    sem = asyncio.Semaphore(CONCURRENCY)

    tasks = [asyncio.create_task(try_proxy(q, phone, sem, OP_TIMEOUT)) for q in pr]
    results = await asyncio.gather(*tasks, return_exceptions=False)

    success = [r for r in results if r.get("ok")]
    failed = [r for r in results if not r.get("ok")]

    print(f"\n== РЕЗУЛЬТАТЫ ==\nУспешно: {len(success)}\nПровалов: {len(failed)}")
    for s in success:
        print("  +", s["proxy"])
    for f in failed:
        print("  -", f["proxy"], "--", f["reason"])

if __name__ == '__main__':
    asyncio.run(main())
