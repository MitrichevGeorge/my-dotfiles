import asyncio
import socks
from telethon import TelegramClient, errors
from pars2 import getproxy_cached
from random import randint

# Получаем список прокси
pr = getproxy_cached()

# Параметры Telegram API
API_ID = 24562157
API_HASH = "6ec6241e31f57d6cbe7e82e6258b2668"

# Настройки многопоточности и таймаутов
CONCURRENCY = 10
OP_TIMEOUT = 12


def random_device_info():
    """Выбирает случайные параметры устройства."""
    z = randint(1, 3)
    if z == 1:
        return ("Pixel 7", "Android 14", "9.0.0")
    elif z == 2:
        return ("HP Pavilion P9", "Windows 11", "3.2.0")
    else:
        return ("iPad Air 12", "iOS 13", "9.12.3")


async def try_proxy(proxy_data, phone, sem: asyncio.Semaphore, timeout: int):
    ip = proxy_data.get("ip")
    port_s = proxy_data.get("port") or ""

    try:
        port = int(port_s)
    except (ValueError, TypeError):
        print(f"[{ip}:{port_s}] Неверный порт — пропуск.")
        return {"proxy": f"{ip}:{port_s}", "ok": False, "reason": "bad_port"}

    proxy = (socks.SOCKS5, ip, port)
    device_model, system_version, app_version = random_device_info()

    async with sem:
        # Создаём клиент без сохранения сессии (session=None)
        client = TelegramClient(
            session=None,
            api_id=API_ID,
            api_hash=API_HASH,
            proxy=proxy,
            device_model=device_model,
            system_version=system_version,
            app_version=app_version,
            lang_code="ru",
            system_lang_code="ru-RU"
        )

        try:
            async with client:
                await asyncio.wait_for(client.connect(), timeout=timeout)
                await asyncio.wait_for(client.send_code_request(phone), timeout=timeout)
                print(f"[{ip}:{port}] ✅ Код успешно запрошен.")
                return {"proxy": f"{ip}:{port}", "ok": True}
        except asyncio.TimeoutError:
            print(f"[{ip}:{port}] ⏱ Timeout — пропуск.")
        except errors.RPCError as e:
            print(f"[{ip}:{port}] 🚫 RPCError: {e}")
        except Exception as e:
            print(f"[{ip}:{port}] ❌ Ошибка: {e}")
        finally:
            await client.disconnect()

        return {"proxy": f"{ip}:{port}", "ok": False}


async def main():
    if not pr:
        print("Нет прокси.")
        return

    phone = input("номер: ").strip()
    sem = asyncio.Semaphore(CONCURRENCY)

    tasks = [asyncio.create_task(try_proxy(p, phone, sem, OP_TIMEOUT)) for p in pr]
    results = await asyncio.gather(*tasks)

    success = [r for r in results if r.get("ok")]
    fail = [r for r in results if not r.get("ok")]

    print("\n=== РЕЗУЛЬТАТ ===")
    print(f"Успешных прокси: {len(success)}")
    for s in success:
        print("  ✅", s["proxy"])
    print(f"Плохих прокси: {len(fail)}")
    for f in fail:
        print("  ❌", f["proxy"], "-", f.get("reason"))


if __name__ == "__main__":
    asyncio.run(main())
