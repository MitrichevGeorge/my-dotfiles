import asyncio
import socks
from telethon import TelegramClient, errors
from telethon.sessions import StringSession
from pars2 import getproxy_cached
from random import randint

pr = getproxy_cached()  # ожидается список dict с ключами "ip" и "port"

# Параметры
API_ID = 24562157
API_HASH = "6ec6241e31f57d6cbe7e82e6258b2668"
CONCURRENCY = 10        # сколько прокси одновременно
OP_TIMEOUT = 12         # таймаут на connect/send (в секундах)

def make_client_for_proxy(proxy_tuple):
    # выбираем рандомные поля device/app для маскировки
    z = randint(1, 3)
    if z == 1:
        device_model = "Pixel 7"
        system_version = "Android 14"
        app_version = "9.0.0"
    elif z == 2:
        device_model = "HP Pavilion P9"
        system_version = "Windows 11"
        app_version = "3.2.0"
    else:
        device_model = "Ipad Air 12"
        system_version = "IOS 13"
        app_version = "9.12.3"

    # Используем StringSession() — сессия в памяти, файлов не создаётся
    session = StringSession()

    client = TelegramClient(
        session,
        API_ID,
        API_HASH,
        proxy=proxy_tuple,
        device_model=device_model,
        system_version=system_version,
        app_version=app_version,
        lang_code="ru",
        system_lang_code="ru-RU"
    )
    return client

async def try_proxy(q, phone, sem: asyncio.Semaphore, timeout: int):
    ip = q.get("ip")
    port_s = q.get("port") or ""
    try:
        port = int(port_s)
    except (ValueError, TypeError):
        print(f"[{ip}:{port_s}] Неправильный порт — пропускаю.")
        return {"proxy": f"{ip}:{port_s}", "ok": False, "reason": "bad_port"}

    proxy_tuple = (socks.SOCKS5, ip, port)

    async with sem:
        client = make_client_for_proxy(proxy_tuple)
        try:
            # подключаемся с таймаутом
            await asyncio.wait_for(client.connect(), timeout=timeout)
        except asyncio.TimeoutError:
            print(f"[{ip}:{port}] Timeout при connect — пропускаю.")
            await safe_disconnect(client)
            return {"proxy": f"{ip}:{port}", "ok": False, "reason": "connect_timeout"}
        except Exception as e:
            print(f"[{ip}:{port}] Ошибка при connect: {e!r}")
            await safe_disconnect(client)
            return {"proxy": f"{ip}:{port}", "ok": False, "reason": f"connect_err:{e}"}

        # если уже авторизован (редко для этого сценария), можно отсечь
        try:
            # запрос кода с таймаутом
            try:
                await asyncio.wait_for(client.send_code_request(phone), timeout=timeout)
                print(f"[{ip}:{port}] Код запрошен успешно.")
                await safe_disconnect(client)
                return {"proxy": f"{ip}:{port}", "ok": True}
            except asyncio.TimeoutError:
                print(f"[{ip}:{port}] Timeout при send_code_request — пропускаю.")
                await safe_disconnect(client)
                return {"proxy": f"{ip}:{port}", "ok": False, "reason": "send_timeout"}
            except errors.RPCError as e:
                # Telethon-ошибки (Flood, bad proxy, wrong DC и т.д.)
                print(f"[{ip}:{port}] RPCError при запросе кода: {e.__class__.__name__}: {e}")
                await safe_disconnect(client)
                return {"proxy": f"{ip}:{port}", "ok": False, "reason": f"rpc:{e}"}
            except Exception as e:
                print(f"[{ip}:{port}] Ошибка при запросе кода: {e!r}")
                await safe_disconnect(client)
                return {"proxy": f"{ip}:{port}", "ok": False, "reason": f"other:{e}"}
        finally:
            # на всякий случай отключаемся, если ещё не отключились
            await safe_disconnect(client)

async def safe_disconnect(client):
    try:
        if client and not client.is_disconnected():
            await client.disconnect()
    except Exception:
        # игнорируем ошибки отключения
        pass

async def main():
    if not pr:
        print("Нет прокси")
        return

    phone = input("номер: ").strip()
    sem = asyncio.Semaphore(CONCURRENCY)
    tasks = [asyncio.create_task(try_proxy(q, phone, sem, OP_TIMEOUT)) for q in pr]

    # собираем результаты, но не прерываем всё при исключении одного task
    results = await asyncio.gather(*tasks, return_exceptions=False)

    # фильтруем успешные прокси
    success = [r for r in results if isinstance(r, dict) and r.get("ok")]
    failed = [r for r in results if isinstance(r, dict) and not r.get("ok")]

    print("\n== РЕЗУЛЬТАТЫ ==")
    print(f"Успехов: {len(success)}")
    for s in success:
        print("  +", s["proxy"])
    print(f"Провалов: {len(failed)}")
    for f in failed:
        print("  -", f["proxy"], "--", f.get("reason"))

if __name__ == '__main__':
    asyncio.run(main())
