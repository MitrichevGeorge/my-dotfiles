# generate.py
import asyncio
from html_generator import generate_html

asyncio.run(generate_html())