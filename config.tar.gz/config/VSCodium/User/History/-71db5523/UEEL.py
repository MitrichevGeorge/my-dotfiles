import uuid
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from telegram.ext import Application, ChatJoinRequestHandler, MessageHandler, filters, ContextTypes, JobQueue
from dotenv import load_dotenv
import os
import time

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN")
ALLOWED_CHAT_ID = int(os.getenv("CHANNEL_ID"))

if not TOKEN or not ALLOWED_CHAT_ID:
    raise ValueError("BOT_TOKEN или CHANNEL_ID не заданы в .env")

PENDING_REQUESTS = {}

async def chat_join_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    req = update.chat_join_request
    user_id = req.from_user.id
    user_chat_id = req.user_chat_id
    chat_id = req.chat.id

    if chat_id != ALLOWED_CHAT_ID:
        return

    token = str(uuid.uuid4())[:8]
    PENDING_REQUESTS[token] = {
        'user_id': user_id,
        'user_chat_id': user_chat_id,
        'chat_id': chat_id,
        'timestamp': time.time()
    }

    button_text = f"Вступить {token}"
    button = KeyboardButton(button_text)
    keyboard = ReplyKeyboardMarkup([[button]], resize_keyboard=True, one_time_keyboard=True)

    try:
        await context.bot.send_message(
            chat_id=user_chat_id,
            text="Нажми кнопку ниже, чтобы вступить в канал:",
            reply_markup=keyboard
        )
    except Exception as e:
        print(f"Ошибка отправки: {e}")
        del PENDING_REQUESTS[token]

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message
    user_id = message.from_user.id
    text = message.text.strip()

    token = None
    for t in PENDING_REQUESTS.keys():
        if f"Вступить {t}" in text:
            token = t
            break

    if not token:
        return

    if token not in PENDING_REQUESTS:
        await message.reply_text("Заявка устарела.", reply_markup=ReplyKeyboardRemove())
        return

    data = PENDING_REQUESTS[token]

    if data['user_id'] != user_id:
        await message.reply_text("Это не твоя заявка!", reply_markup=ReplyKeyboardRemove())
        return

    if time.time() - data['timestamp'] > 3600:
        await message.reply_text("Срок действия заявки истёк.", reply_markup=ReplyKeyboardRemove())
        del PENDING_REQUESTS[token]
        return

    try:
        await context.bot.approve_chat_join_request(
            chat_id=data['chat_id'],
            user_id=user_id
        )
        await message.reply_text(
            "Добро пожаловать в ShadowTech! 🎉",
            reply_markup=ReplyKeyboardRemove()
        )
    except Exception as e:
        if "already" in str(e).lower() or "badrequest" in str(e).lower():
            await message.reply_text("Заявка уже обработана.")
        else:
            await message.reply_text("Ошибка при обработке.")
    finally:
        del PENDING_REQUESTS[token]

async def cleaner(context: ContextTypes.DEFAULT_TYPE):
    now = time.time()
    expired_tokens = [
        token for token, data in PENDING_REQUESTS.items()
        if now - data['timestamp'] > 3600
    ]
    for token in expired_tokens:
        del PENDING_REQUESTS[token]

def main():
    app = Application.builder().token(TOKEN).build()

    app.job_queue.run_repeating(
        cleaner,
        interval=600,
        first=10
    )

    app.add_handler(ChatJoinRequestHandler(chat_join_request))
    
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    print("Бот запущен...")
    app.run_polling()

if __name__ == '__main__':
    main()