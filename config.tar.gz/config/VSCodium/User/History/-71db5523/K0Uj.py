import uuid
import asyncio
import aiosqlite
import os
import time
import logging
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import Application, ChatJoinRequestHandler, CommandHandler, ContextTypes
from dotenv import load_dotenv
import secrets
from collections import defaultdict

load_dotenv()

TOKEN = os.getenv("BOT_TOKEN")
ALLOWED_CHAT_ID = int(os.getenv("CHANNEL_ID"))

if not TOKEN or not ALLOWED_CHAT_ID:
    raise ValueError("BOT_TOKEN или CHANNEL_ID не заданы в .env")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DB_PATH = "requests.db"
ANT2FLOOD_DELAY = 1.0
LAST_MSG = defaultdict(float)
_last_msg_lock = asyncio.Lock()
_cleaner_running = False


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS pending (
                token TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                user_chat_id INTEGER NOT NULL,
                chat_id INTEGER NOT NULL,
                timestamp REAL NOT NULL
            )
        """)
        await db.execute("CREATE INDEX IF NOT EXISTS idx_user_id ON pending(user_id)")
        await db.commit()


async def add_request(token: str, user_id: int, user_chat_id: int, chat_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO pending VALUES (?, ?, ?, ?, ?)",
            (token, user_id, user_chat_id, chat_id, time.time())
        )
        await db.commit()


async def has_active_request(user_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT 1 FROM pending WHERE user_id = ? LIMIT 1", (user_id,)) as cur:
            return await cur.fetchone() is not None


async def approve_and_delete(token: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN")
        try:
            async with db.execute("SELECT * FROM pending WHERE token = ? FOR UPDATE", (token,)) as cur:
                row = await cur.fetchone()
                if not row:
                    return None
                data = dict(zip(["token", "user_id", "user_chat_id", "chat_id", "timestamp"], row))

            await db.execute("DELETE FROM pending WHERE token = ?", (token,))
            await db.commit()
            return data
        except Exception as e:
            await db.rollback()
            logger.error(f"DB error in approve_and_delete: {e}")
            raise


async def clean_expired():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM pending WHERE timestamp < ?", (time.time() - 3600))
        await db.commit()

async def chat_join_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    req = update.chat_join_request
    user_id = req.from_user.id
    user_chat_id = req.user_chat_id
    chat_id = req.chat.id

    if chat_id != ALLOWED_CHAT_ID:
        await req.decline()
        return

    if await has_active_request(user_id):
        await req.decline()
        return

    token = secrets.token_urlsafe(16)
    await add_request(token, user_id, user_chat_id, chat_id)

    bot = context.bot
    bot_user = await bot.get_me()
    bot_username = bot_user.username
    url = f"https://t.me/{bot_username}?start={token}"

    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton("Вступить в канал", url=url)
    ]])

    try:
        await bot.send_message(
            chat_id=user_chat_id,
            text="Нажмите кнопку ниже, чтобы вступить в канал:",
            reply_markup=keyboard
        )
        logger.info(f"Sent invite to user {user_id} (chat_id={user_chat_id})")
    except Exception as e:
        logger.error(f"Failed to send message to {user_id}: {e}")
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM pending WHERE token = ?", (token,))
            await db.commit()
        await req.decline()


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    message = update.effective_message

    if message.chat.type != "private":
        await message.reply_text("Используйте команду в личных сообщениях с ботом.")
        return

    async with _last_msg_lock:
        now = time.time()
        if user_id in LAST_MSG and now - LAST_MSG[user_id] < ANT2FLOOD_DELAY:
            return
        LAST_MSG[user_id] = now

    if not context.args:
        await message.reply_text("Привет! Используйте кнопку из приглашения.")
        return

    token = context.args[0].strip()
    if len(token) > 100:  # Защита от мусора
        await message.reply_text("Недопустимый токен.")
        return

    try:
        data = await approve_and_delete(token)
    except Exception as e:
        logger.error(f"DB error during approve: {e}")
        await message.reply_text("Произошла ошибка. Попробуйте позже.")
        return

    if not data:
        await message.reply_text("Заявка устарела или недействительна.")
        return

    if data["user_id"] != user_id:
        await message.reply_text("Это не ваша заявка!")
        return

    if time.time() - data["timestamp"] > 3600:
        await message.reply_text("Срок действия заявки истёк.")
        return

    try:
        await context.bot.approve_chat_join_request(
            chat_id=data["chat_id"],
            user_id=user_id
        )
        await message.reply_text("Добро пожаловать в ShadowTech!")
        logger.info(f"APPROVED: user_id={user_id}, chat_id={data['chat_id']}, token={token}")
    except Exception as e:
        logger.error(f"Failed to approve {user_id}: {e}")
        await message.reply_text("Произошла ошибка при вступлении.")
        try:
            await context.bot.decline_chat_join_request(chat_id=data["chat_id"], user_id=user_id)
        except:
            pass


async def cleaner_loop():
    global _cleaner_running
    if _cleaner_running:
        return
    _cleaner_running = True

    while True:
        try:
            await clean_expired()
            logger.debug("Cleaned expired requests")
        except Exception as e:
            logger.error(f"Cleaner loop error: {e}")
        await asyncio.sleep(600)


async def main():
    await init_db()

    app = Application.builder().token(TOKEN).build()

    app.add_handler(ChatJoinRequestHandler(chat_join_request))
    app.add_handler(CommandHandler("start", start_command))

    asyncio.create_task(cleaner_loop())

    logger.info("Бот запущен и готов к работе...")
    await app.run_polling(drop_pending_updates=True, allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    asyncio.run(main())