import uuid
import asyncio
import aiosqlite
import os
import time
import logging
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import Application, ChatJoinRequestHandler, CommandHandler, ContextTypes
from telegram.error import Forbidden, BadRequest
from dotenv import load_dotenv
import secrets
from collections import defaultdict
from aiolimiter import AsyncLimiter

load_dotenv()

TOKEN = os.getenv("BOT_TOKEN")
ALLOWED_CHAT_ID = int(os.getenv("CHANNEL_ID"))

if not TOKEN or not ALLOWED_CHAT_ID:
    raise ValueError("BOT_TOKEN или CHANNEL_ID не заданы в .env")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DB_PATH = "requests.db"
TOKEN_EXPIRY = 3600  # 1 час
CLEANUP_INTERVAL = 600  # 10 минут
ANTIFLOOD_DELAY = 1.0
MAX_FAILED_ATTEMPTS = 5
BAN_DURATION = 300  # 5 минут

# Rate limiting
start_limiter = AsyncLimiter(1, ANTIFLOOD_DELAY)  # 1 /start в секунду на пользователя
failed_attempts = defaultdict(lambda: {"count": 0, "until": 0})

LAST_MSG = defaultdict(float)
_last_msg_lock = asyncio.Lock()
_cleaner_running = False


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS pending (
                token TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                user_chat_id INTEGER NOT NULL,
                chat_id INTEGER NOT NULL,
                timestamp REAL NOT NULL
            )
        """)
        await db.execute("CREATE INDEX IF NOT EXISTS idx_user_id ON pending(user_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_user_chat_id ON pending(user_chat_id)")
        await db.commit()


async def add_request(token: str, user_id: int, user_chat_id: int, chat_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO pending VALUES (?, ?, ?, ?, ?)",
            (token, user_id, user_chat_id, chat_id, time.time())
        )
        await db.commit()


async def has_active_request_by_user_id(user_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT 1 FROM pending WHERE user_id = ? LIMIT 1", (user_id,)) as cur:
            return await cur.fetchone() is not None


async def has_active_request_by_chat_id(user_chat_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT 1 FROM pending WHERE user_chat_id = ? LIMIT 1", (user_chat_id,)) as cur:
            return await cur.fetchone() is not None


async def get_and_delete_request(token: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN")
        try:
            async with db.execute("SELECT * FROM pending WHERE token = ? FOR UPDATE", (token,)) as cur:
                row = await cur.fetchone()
                if not row:
                    return None
                data = dict(zip(["token", "user_id", "user_chat_id", "chat_id", "timestamp"], row))

            await db.execute("DELETE FROM pending WHERE token = ?", (token,))
            await db.commit()
            return data
        except Exception as e:
            await db.rollback()
            logger.error(f"DB error in get_and_delete_request: {e}")
            raise


async def clean_expired():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM pending WHERE timestamp < ?", (time.time() - TOKEN_EXPIRY))
        await db.commit()


async def chat_join_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    req = update.chat_join_request
    user_id = req.from_user.id
    user_chat_id = req.user_chat_id
    chat_id = req.chat.id

    if chat_id != ALLOWED_CHAT_ID:
        await req.decline()
        return

    # Блокируем по user_chat_id — одна заявка на чат
    if await has_active_request_by_chat_id(user_chat_id):
        await req.decline()
        return

    if await has_active_request_by_user_id(user_id):
        await req.decline()
        return

    token = secrets.token_urlsafe(16)
    await add_request(token, user_id, user_chat_id, chat_id)

    bot = context.bot
    bot_user = await bot.get_me()
    bot_username = bot_user.username
    url = f"https://t.me/{bot_username}?start={token}"

    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton("Вступить в канал", url=url)
    ]])

    try:
        await bot.send_message(
            chat_id=user_chat_id,
            text="Нажмите кнопку ниже, чтобы вступить в канал:",
            reply_markup=keyboard
        )
        logger.info(f"Sent invite to user {user_id} (chat_id={user_chat_id})")
    except Exception as e:
        logger.error(f"Failed to send message to {user_id}: {e}")
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM pending WHERE token = ?", (token,))
            await db.commit()
        await req.decline()


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    message = update.effective_message

    if message.chat.type != "private":
        await message.reply_text("Используйте команду в личных сообщениях с ботом.")
        return

    # Глобальный антифлуд
    async with _last_msg_lock:
        now = time.time()
        if user_id in LAST_MSG and now - LAST_MSG[user_id] < ANTIFLOOD_DELAY:
            return
        LAST_MSG[user_id] = now

    # Локальный лимитер через aiolimiter
    async with start_limiter:
        pass

    if not context.args:
        await message.reply_text("Привет! Используйте кнопку из приглашения.")
        return

    token = context.args[0].strip()
    if len(token) > 100:
        await message.reply_text("Недопустимый токен.")
        return

    # Проверка бана за перебор токенов
    if failed_attempts[user_id]["until"] > time.time():
        await message.reply_text("Слишком много попыток. Попробуйте позже.")
        return

    try:
        data = await get_and_delete_request(token)
    except Exception as e:
        logger.error(f"DB error during approve: {e}")
        await message.reply_text("Произошла ошибка. Попробуйте позже.")
        return

    if not data:
        failed_attempts[user_id]["count"] += 1
        if failed_attempts[user_id]["count"] >= MAX_FAILED_ATTEMPTS:
            failed_attempts[user_id]["until"] = time.time() + BAN_DURATION
            await message.reply_text(f"Слишком много неудачных попыток. Блокировка на {BAN_DURATION//60} мин.")
        else:
            await message.reply_text("Заявка устарела или недействительна.")
        return

    # Сброс счётчика при успехе
    failed_attempts[user_id] = {"count": 0, "until": 0}

    if data["user_id"] != user_id:
        await message.reply_text("Это не ваша заявка!")
        return

    if time.time() - data["timestamp"] > TOKEN_EXPIRY:
        await message.reply_text("Срок действия заявки истёк.")
        return

    try:
        await context.bot.approve_chat_join_request(
            chat_id=data["chat_id"],
            user_id=user_id
        )
        await message.reply_text("Добро пожаловать в ShadowTech!")
        logger.info(f"APPROVED: user_id={user_id}, chat_id={data['chat_id']}, token={token}")
    except BadRequest as e:
        if "USER_ALREADY_PARTICIPANT" in str(e):
            await message.reply_text("Вы уже в канале!")
        else:
            logger.error(f"BadRequest on approve {user_id}: {e}")
            await message.reply_text("Ошибка: заявка недействительна.")
    except Forbidden:
        await message.reply_text("Бот не имеет прав на одобрение заявок.")
        logger.error(f"Bot has no admin rights in chat {data['chat_id']}")
    except Exception as e:
        logger.error(f"Failed to approve {user_id}: {e}")
        await message.reply_text("Произошла ошибка при вступлении.")
        # Попытка отклонить, если не получилось одобрить
        try:
            await context.bot.decline_chat_join_request(chat_id=data["chat_id"], user_id=user_id)
        except:
            pass


async def cleaner_loop():
    global _cleaner_running
    if _cleaner_running:
        return
    _cleaner_running = True

    while True:
        try:
            await clean_expired()
            logger.debug("Cleaned expired requests")
        except Exception as e:
            logger.error(f"Cleaner loop error: {e}")
        await asyncio.sleep(CLEANUP_INTERVAL)


async def main():
    await init_db()

    app = Application.builder().token(TOKEN).build()

    app.add_handler(ChatJoinRequestHandler(chat_join_request))
    app.add_handler(CommandHandler("start", start_command))

    asyncio.create_task(cleaner_loop())

    logger.info("Бот запущен и готов к работе...")
    await app.run_polling(drop_pending_updates=True, allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    asyncio.run(main())