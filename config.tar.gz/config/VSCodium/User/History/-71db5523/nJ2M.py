import uuid
import asyncio
import aiosqlite
import os
import time
import logging
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from telegram.ext import Application, ChatJoinRequestHandler, MessageHandler, filters, ContextTypes
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("BOT_TOKEN")
ALLOWED_CHAT_ID = int(os.getenv("CHANNEL_ID"))

if not TOKEN or not ALLOWED_CHAT_ID:
    raise ValueError("BOT_TOKEN или CHANNEL_ID не заданы в .env")

logging.basicConfig(level=logging.INFO)

DB_PATH = "requests.db"
ANTIFLOOD_DELAY = 1.0

LAST_MSG = {}


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS pending (
                token TEXT PRIMARY KEY,
                user_id INTEGER,
                user_chat_id INTEGER,
                chat_id INTEGER,
                timestamp REAL
            )
        """)
        await db.commit()


async def add_request(token, user_id, user_chat_id, chat_id):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR REPLACE INTO pending VALUES (?, ?, ?, ?, ?)",
            (token, user_id, user_chat_id, chat_id, time.time())
        )
        await db.commit()


async def get_request_by_token(token):
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT * FROM pending WHERE token = ?", (token,)) as cur:
            row = await cur.fetchone()
            if row:
                return dict(zip(["token", "user_id", "user_chat_id", "chat_id", "timestamp"], row))
    return None


async def delete_request(token):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM pending WHERE token = ?", (token,))
        await db.commit()


async def clean_expired():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM pending WHERE timestamp < ?", (time.time() - 3600))
        await db.commit()


async def chat_join_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    req = update.chat_join_request
    user_id = req.from_user.id
    user_chat_id = req.user_chat_id
    chat_id = req.chat.id

    if chat_id != ALLOWED_CHAT_ID:
        return

    token = str(uuid.uuid4())[:12]
    await add_request(token, user_id, user_chat_id, chat_id)

    button = KeyboardButton(f"Вступить {token}")
    keyboard = ReplyKeyboardMarkup([[button]], resize_keyboard=True, one_time_keyboard=True)

    try:
        await context.bot.send_message(
            chat_id=user_chat_id,
            text="Нажми кнопку ниже, чтобы вступить в канал:",
            reply_markup=keyboard
        )
    except Exception as e:
        logging.error(f"Ошибка отправки пользователю {user_id}: {e}")
        await delete_request(token)


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message
    user_id = message.from_user.id
    text = message.text.strip()

    # антифлуд
    if time.time() - LAST_MSG.get(user_id, 0) < ANTIFLOOD_DELAY:
        return
    LAST_MSG[user_id] = time.time()

    if not text.startswith("Вступить "):
        return

    token = text.split(" ", 1)[1].strip()
    data = await get_request_by_token(token)
    if not data:
        await message.reply_text("Заявка устарела или неверный токен.", reply_markup=ReplyKeyboardRemove())
        return

    if data["user_id"] != user_id:
        await message.reply_text("Это не твоя заявка!", reply_markup=ReplyKeyboardRemove())
        return

    if time.time() - data["timestamp"] > 3600:
        await message.reply_text("Срок действия заявки истёк.", reply_markup=ReplyKeyboardRemove())
        await delete_request(token)
        return

    try:
        await context.bot.approve_chat_join_request(chat_id=data["chat_id"], user_id=user_id)
        await message.reply_text("Добро пожаловать в ShadowTech 🎉", reply_markup=ReplyKeyboardRemove())
    except Exception as e:
        logging.error(f"Ошибка при approve для {user_id}: {e}")
        await message.reply_text("Ошибка при обработке.")
    finally:
        await delete_request(token)


async def cleaner_loop():
    while True:
        await clean_expired()
        await asyncio.sleep(600)


async def main():
    await init_db()
    app = Application.builder().token(TOKEN).build()

    app.add_handler(ChatJoinRequestHandler(chat_join_request))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    asyncio.create_task(cleaner_loop())

    logging.info("Бот запущен...")
    await app.run_polling()


if __name__ == "__main__":
    asyncio.run(main())
