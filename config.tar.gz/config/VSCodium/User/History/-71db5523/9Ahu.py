import asyncio
import aiosqlite
import os
import time
import logging
import re
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import Application, ChatJoinRequestHandler, CommandHandler, ContextTypes
from telegram.error import Forbidden, BadRequest
from dotenv import load_dotenv
import secrets
from collections import defaultdict
from aiolimiter import AsyncLimiter

load_dotenv()

TOKEN = os.getenv("BOT_TOKEN")
ALLOWED_CHAT_ID = int(os.getenv("CHANNEL_ID"))

if not TOKEN or not ALLOWED_CHAT_ID:
    raise ValueError("BOT_TOKEN или CHANNEL_ID не заданы в .env")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DB_PATH = "requests.db"
TOKEN_EXPIRY = 3600
CLEANUP_INTERVAL = 600
ANTIFLOOD_DELAY = 1.0
MAX_FAILED_ATTEMPTS = 5
BAN_DURATION = 300
MAX_ACTIVE_REQUESTS = 3

# Лимитеры
start_limiter = AsyncLimiter(1, ANTIFLOOD_DELAY)
join_limiter = AsyncLimiter(20, 1)

# Глобальные переменные
LAST_MSG = defaultdict(float)
_last_msg_lock = asyncio.Lock()
_cleaner_running = False
_user_locks = defaultdict(asyncio.Lock)


async def init_db():
    async with aiosqlite.connect(DB_PATH, timeout=10) as db:
        await db.execute("PRAGMA journal_mode=WAL;")
        await db.execute("PRAGMA busy_timeout = 5000;")
        await db.execute("""
            CREATE TABLE IF NOT EXISTS pending (
                token TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                from_chat_id INTEGER NOT NULL,
                chat_id INTEGER NOT NULL,
                timestamp REAL NOT NULL,
                used INTEGER DEFAULT 0
            )
        """)
        await db.execute("CREATE INDEX IF NOT EXISTS idx_user_id ON pending(user_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_from_chat_id ON pending(from_chat_id)")

        await db.execute("""
            CREATE TABLE IF NOT EXISTS failed_attempts (
                user_id INTEGER PRIMARY KEY,
                count INTEGER NOT NULL,
                until REAL NOT NULL
            )
        """)
        await db.commit()
    logger.info("База данных инициализирована")


async def add_request(token: str, user_id: int, from_chat_id: int, chat_id: int):
    async with aiosqlite.connect(DB_PATH, timeout=10) as db:
        await db.execute(
            "INSERT INTO pending (token, user_id, from_chat_id, chat_id, timestamp) VALUES (?, ?, ?, ?, ?)",
            (token, user_id, from_chat_id, chat_id, time.time())
        )
        await db.commit()


async def count_active_requests(user_id: int) -> int:
    async with aiosqlite.connect(DB_PATH, timeout=10) as db:
        async with db.execute("SELECT COUNT(*) FROM pending WHERE user_id = ? AND used = 0", (user_id,)) as cur:
            return (await cur.fetchone())[0]


async def has_active_request_by_user_id(user_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH, timeout=10) as db:
        async with db.execute("SELECT 1 FROM pending WHERE user_id = ? AND used = 0 LIMIT 1", (user_id,)) as cur:
            return await cur.fetchone() is not None


async def has_active_request_by_chat_id(from_chat_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH, timeout=10) as db:
        async with db.execute("SELECT 1 FROM pending WHERE from_chat_id = ? AND used = 0 LIMIT 1", (from_chat_id,)) as cur:
            return await cur.fetchone() is not None


async def get_request(token: str):
    async with aiosqlite.connect(DB_PATH, timeout=10) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT * FROM pending WHERE token = ? AND used = 0 FOR UPDATE", (token,)) as cur:
                row = await cur.fetchone()
                if not row:
                    await db.rollback()
                    return None
                data = dict(zip(["token", "user_id", "from_chat_id", "chat_id", "timestamp", "used"], row))
            await db.commit()
            return data
        except Exception as e:
            await db.rollback()
            logger.error(f"DB error in get_request: {e}")
            raise


async def mark_token_used(token: str):
    async with aiosqlite.connect(DB_PATH, timeout=10) as db:
        await db.execute("UPDATE pending SET used = 1 WHERE token = ?", (token,))
        await db.commit()


async def clean_expired():
    async with aiosqlite.connect(DB_PATH, timeout=10) as db:
        deleted = await db.execute_fetchall(
            "DELETE FROM pending WHERE timestamp < ? OR used = 1 RETURNING token",
            (time.time() - TOKEN_EXPIRY,)
        )
        banned = await db.execute_fetchall("DELETE FROM failed_attempts WHERE until < ? RETURNING user_id", (time.time(),))
        await db.commit()
    if deleted:
        logger.debug(f"Удалено {len(deleted)} записей (истёкшие или использованные)")
    if banned:
        logger.debug(f"Снята блокировка с {len(banned)} пользователей")


async def get_failed_attempts(user_id: int) -> dict:
    async with aiosqlite.connect(DB_PATH, timeout=10) as db:
        async with db.execute("SELECT count, until FROM failed_attempts WHERE user_id = ?", (user_id,)) as cur:
            row = await cur.fetchone()
            return {"count": row[0], "until": row[1]} if row else {"count": 0, "until": 0}


async def update_failed_attempts(user_id: int, count: int, until: float):
    async with aiosqlite.connect(DB_PATH, timeout=10) as db:
        await db.execute(
            "INSERT OR REPLACE INTO failed_attempts (user_id, count, until) VALUES (?, ?, ?)",
            (user_id, count, until)
        )
        await db.commit()


async def chat_join_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    req = update.chat_join_request
    user_id = req.from_user.id
    from_chat_id = req.user_chat_id
    chat_id = req.chat.id

    if chat_id != ALLOWED_CHAT_ID:
        await req.decline()
        return

    async with _user_locks[user_id]:
        async with join_limiter:
            if await has_active_request_by_chat_id(from_chat_id):
                await req.decline()
                return

            if await has_active_request_by_user_id(user_id):
                await req.decline()
                return

            if await count_active_requests(user_id) >= MAX_ACTIVE_REQUESTS:
                await req.decline()
                return

            token = secrets.token_urlsafe(16)
            await add_request(token, user_id, from_chat_id, chat_id)

            bot = context.bot
            bot_user = await bot.get_me()
            bot_username = bot_user.username
            url = f"https://t.me/{bot_username}?start={token}"

            keyboard = InlineKeyboardMarkup([[
                InlineKeyboardButton("Вступить в канал", url=url)
            ]])

            try:
                await bot.send_message(
                    chat_id=from_chat_id,
                    text="Нажмите кнопку ниже, чтобы вступить в канал:",
                    reply_markup=keyboard
                )
                logger.info(f"Приглашение отправлено: user_id={user_id}, from_chat_id={from_chat_id}")
            except Forbidden:
                logger.info(f"Пользователь {user_id} заблокировал бота — заявка отклонена")
                await mark_token_used(token)
                await req.decline()
                return
            except Exception as e:
                logger.error(f"Ошибка отправки: {e}")
                await mark_token_used(token)
                await req.decline()
                return


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    message = update.effective_message

    if message.chat.type != "private":
        await message.reply_text("Используйте команду в личных сообщениях с ботом.")
        return

    async with _last_msg_lock:
        now = time.time()
        if user_id in LAST_MSG and now - LAST_MSG[user_id] < ANTIFLOOD_DELAY:
            return
        LAST_MSG[user_id] = now

    async with start_limiter:
        pass

    if not context.args:
        await message.reply_text("Привет! Используйте кнопку из приглашения.")
        return

    token = context.args[0].strip()

    if not re.fullmatch(r'[A-Za-z0-9_-]{22}', token):
        await message.reply_text("Недопустимый токен.")
        logger.warning(f"Подозрительный токен: user_id={user_id}, token={token}")
        return

    failed = await get_failed_attempts(user_id)
    if failed["until"] > time.time():
        await message.reply_text(f"Слишком много попыток. Подождите {int((failed['until'] - time.time()) / 60)} мин.")
        return

    try:
        data = await get_request(token)
    except Exception as e:
        logger.error(f"DB error: {e}")
        await message.reply_text("Произошла ошибка. Попробуйте позже.")
        return

    if not data:
        failed["count"] += 1
        if failed["count"] >= MAX_FAILED_ATTEMPTS:
            ban_until = time.time() + BAN_DURATION
            await update_failed_attempts(user_id, failed["count"], ban_until)
            await message.reply_text(f"Слишком много неудачных попыток. Блокировка на {BAN_DURATION//60} мин.")
        else:
            await update_failed_attempts(user_id, failed["count"], failed["until"])
            await message.reply_text("Заявка устарела или недействительна.")
        return

    await update_failed_attempts(user_id, 0, 0)

    if message.chat.id != data["from_chat_id"]:
        await message.reply_text("Эта ссылка предназначена для другого чата.")
        logger.warning(f"Чужой чат: user_id={user_id}, expected={data['from_chat_id']}")
        return

    if data["user_id"] != user_id:
        await message.reply_text("Это не ваша заявка!")
        return

    if time.time() - data["timestamp"] > TOKEN_EXPIRY:
        await message.reply_text("Срок действия заявки истёк.")
        return

    try:
        await context.bot.approve_chat_join_request(chat_id=data["chat_id"], user_id=user_id)
        await mark_token_used(token)
        await message.reply_text("Добро пожаловать в ShadowTech!")
        logger.info(f"ОДОБРЕНО: user_id={user_id}, token={token}")
    except BadRequest as e:
        if "USER_ALREADY_PARTICIPANT" in str(e):
            await mark_token_used(token)
            await message.reply_text("Вы уже в канале!")
        else:
            logger.error(f"BadRequest: {e}")
            await message.reply_text("Ошибка: заявка недействительна.")
    except Forbidden:
        await message.reply_text("Бот не имеет прав на одобрение заявок.")
        logger.error(f"Нет прав в канале {data['chat_id']}")
    except Exception as e:
        logger.error(f"Ошибка одобрения: {e}")
        await message.reply_text("Произошла ошибка при вступлении.")
        try:
            await context.bot.decline_chat_join_request(chat_id=data["chat_id"], user_id=user_id)
        except:
            pass


async def cleaner_loop():
    global _cleaner_running
    while True:
        try:
            if _cleaner_running:
                await asyncio.sleep(1)
                continue
            _cleaner_running = True
            logger.info("Очиститель запущен")
            while True:
                await clean_expired()
                await asyncio.sleep(CLEANUP_INTERVAL)
        except asyncio.CancelledError:
            logger.info("Очиститель остановлен")
            raise
        except Exception as e:
            logger.error(f"Очиститель упал: {e}. Перезапуск через 10 сек...")
            await asyncio.sleep(10)
        finally:
            _cleaner_running = False


async def check_bot_permissions(app: Application):
    bot = app.bot
    try:
        chat = await bot.get_chat(ALLOWED_CHAT_ID)
        if chat.type != "channel":
            raise ValueError(f"ID {ALLOWED_CHAT_ID} — не канал")

        admins = await bot.get_chat_administrators(ALLOWED_CHAT_ID)
        if bot.id not in [admin.user.id for admin in admins]:
            raise ValueError("Бот не администратор канала")

        member = await bot.get_chat_member(ALLOWED_CHAT_ID, bot.id)
        if not member.can_invite_users:
            raise ValueError("У бота нет права 'can_invite_users'")

        logger.info("Проверка прав бота пройдена")
    except Exception as e:
        logger.critical(f"Критичная ошибка прав: {e}")
        raise


async def main():
    await init_db()

    app = Application.builder().token(TOKEN).build()

    app.add_handler(ChatJoinRequestHandler(chat_join_request))
    app.add_handler(CommandHandler("start", start_command))

    # Запускаем очиститель
    cleaner_task = asyncio.create_task(cleaner_loop())

    # Проверка прав ДО запуска polling
    try:
        await check_bot_permissions(app)
    except Exception as e:
        logger.critical(f"Бот не имеет нужных прав. Остановка: {e}")
        cleaner_task.cancel()
        try:
            await cleaner_task
        except asyncio.CancelledError:
            pass
        return

    logger.info("Бот запущен и готов к работе...")

    try:
        # Используем async with для корректного shutdown
        async with app:
            await app.start()
            await app.updater.start_polling(
                drop_pending_updates=True,
                allowed_updates=Update.ALL_TYPES,
            )
            # Держим приложение запущенным
            while True:
                await asyncio.sleep(3600)
    except asyncio.CancelledError:
        logger.info("Получен сигнал остановки")
    except Exception as e:
        logger.critical(f"Критическая ошибка: {e}")
    finally:
        logger.info("Останавливаем бота...")
        cleaner_task.cancel()
        try:
            await cleaner_task
        except asyncio.CancelledError:
            pass
        await app.updater.stop()
        await app.stop()
        await app.shutdown()
        logger.info("Бот успешно остановлен")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Остановка по Ctrl+C")
    except Exception as e:
        logger.critical(f"Необработанное исключение: {e}")