#!/bin/bash

# Получаем список доступных устройств
DEVICES=$(bluetoothctl devices | awk '{print $2 " " $3}')

# Показываем через Wofi
CHOSEN=$(echo "$DEVICES" | wofi --dmenu --prompt "Bluetooth Devices:")

if [ -n "$CHOSEN" ]; then
    # Получаем MAC адрес выбранного устройства
    MAC=$(echo "$CHOSEN" | awk '{print $1}')
    
    # Подключаем выбранное устройство
    bluetoothctl connect "$MAC"
fi
